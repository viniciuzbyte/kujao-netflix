package com.kujao.netflix

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay

class Shelf(val title: String, val items: List<Item>)

class HomeData {
    var hero by mutableStateOf<Item?>(null)
    var rows by mutableStateOf<List<Shelf>>(emptyList())
    var loading by mutableStateOf(true)
    var failed by mutableStateOf(false)
}

suspend fun loadHome(h: HomeData, filter: String, c: Country) {
    h.loading = true
    h.failed = false
    val lang = c.ui
    val shelves = coroutineScope {
        val types = if (filter == "all") listOf("movie", "tv") else listOf(filter)
        val pop = types.map { t ->
            async {
                val label = if (t == "tv") I18n.t(lang, K.Series) else I18n.t(lang, K.Movies)
                Shelf(
                    I18n.t(lang, K.Popular) + " · " + label,
                    runCatching { Api.discover(t, c.tag) }.getOrDefault(emptyList())
                )
            }
        }
        val gt = if (filter == "tv") "tv" else "movie"
        val genres = runCatching { Api.genres(gt, c.tag) }.getOrDefault(emptyList()).take(8)
        val gr = genres.map { g ->
            async {
                Shelf(
                    g.name,
                    runCatching { Api.discover(gt, c.tag, 1, g.id) }.getOrDefault(emptyList())
                )
            }
        }
        (pop + gr).awaitAll().filter { it.items.isNotEmpty() }
    }
    h.rows = shelves
    h.hero = shelves.firstOrNull()?.items?.firstOrNull { it.posterPath != null }
    h.failed = shelves.isEmpty()
    h.loading = false
}

@Composable
fun Poster(item: Item, modifier: Modifier, onClick: () -> Unit) {
    AsyncImage(
        model = img(item.posterPath),
        contentDescription = item.label,
        contentScale = ContentScale.Crop,
        modifier = modifier
            .aspectRatio(2f / 3f)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
    )
}

@Composable
fun HomeScreen(app: AppState, nav: (Route) -> Unit) {
    val c = app.country ?: return
    val h = app.home
    var retry by remember { mutableIntStateOf(0) }
    LaunchedEffect(app.filter, c.tag, retry) { loadHome(h, app.filter, c) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Column(Modifier.statusBarsPadding()) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("K", color = Red, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(12.dp))
                    Text(tr(K.Home), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Row(
                    Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("all" to K.All, "movie" to K.Movies, "tv" to K.Series).forEach { (f, k) ->
                        FilterChip(
                            selected = app.filter == f,
                            onClick = { app.filter = f },
                            label = { Text(tr(k)) }
                        )
                    }
                }
            }
        }
        if (h.loading && h.rows.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Red)
                }
            }
        }
        if (h.failed && !h.loading) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = { retry++ },
                        colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                    ) { Text(tr(K.Retry)) }
                }
            }
        }
        h.hero?.let { hero ->
            item {
                Box(
                    Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                        .aspectRatio(0.72f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { nav(Route.Detail(hero.type, hero.id)) }
                ) {
                    AsyncImage(
                        model = img(hero.posterPath, "w780"),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    0.45f to Color.Transparent,
                                    1f to Color(0xF2000000)
                                )
                            )
                    )
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            hero.label,
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            maxLines = 2
                        )
                        Text(
                            "${hero.year}  ·  ★ ${"%.1f".format(hero.voteAverage)}",
                            color = Color(0xFFD0D0D0),
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { nav(Route.Player(hero.type, hero.id, hero.label)) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                        ) {
                            Icon(Icons.Filled.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text(tr(K.Play), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { nav(Route.Detail(hero.type, hero.id)) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0x66FFFFFF), contentColor = Color.White)
                        ) {
                            Icon(Icons.Filled.Info, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Info", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
        items(h.rows) { s ->
            Text(
                s.title,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(s.items) { it ->
                    Poster(it, Modifier.width(112.dp)) { nav(Route.Detail(it.type, it.id)) }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(app: AppState, nav: (Route) -> Unit) {
    val c = app.country ?: return
    var q by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Item>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(q, c.tag) {
        if (q.trim().length < 2) {
            results = emptyList()
            busy = false
            return@LaunchedEffect
        }
        delay(450)
        busy = true
        results = runCatching { Api.search(q.trim(), c.tag) }.getOrDefault(emptyList())
        busy = false
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            placeholder = { Text(tr(K.SearchHint)) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (busy) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Red)
            } else if (q.trim().length >= 2 && results.isEmpty()) {
                Text(
                    tr(K.NoResult),
                    Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(results) { it ->
                        Poster(it, Modifier.fillMaxWidth()) { nav(Route.Detail(it.type, it.id)) }
                    }
                }
            }
        }
    }
}
