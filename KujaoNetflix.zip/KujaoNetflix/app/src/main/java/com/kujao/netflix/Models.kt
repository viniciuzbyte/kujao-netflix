package com.kujao.netflix

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Item(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    val overview: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("media_type") val mediaType: String? = null
) {
    val label: String get() = title ?: name ?: ""
    val year: String get() = (releaseDate ?: firstAirDate)?.take(4) ?: ""
    val type: String get() = mediaType ?: if (name != null && title == null) "tv" else "movie"
}

@Serializable
data class Page(val results: List<Item> = emptyList())

@Serializable
data class Genre(val id: Int, val name: String)

@Serializable
data class GenreList(val genres: List<Genre> = emptyList())

@Serializable
data class Video(
    val key: String = "",
    val site: String = "",
    val type: String = "",
    val official: Boolean = false
)

@Serializable
data class Videos(val results: List<Video> = emptyList())

@Serializable
data class ExternalIds(
    @SerialName("imdb_id") val imdbId: String? = null
)

@Serializable
data class SeasonRef(
    @SerialName("season_number") val seasonNumber: Int,
    val name: String = "",
    @SerialName("episode_count") val episodeCount: Int = 0
)

@Serializable
data class Detail(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    val overview: String? = null,
    val tagline: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    val runtime: Int? = null,
    @SerialName("episode_run_time") val episodeRunTime: List<Int> = emptyList(),
    val genres: List<Genre> = emptyList(),
    val videos: Videos = Videos(),
    @SerialName("external_ids") val externalIds: ExternalIds = ExternalIds(),
    val seasons: List<SeasonRef> = emptyList()
) {
    val label: String get() = title ?: name ?: ""
    val year: String get() = (releaseDate ?: firstAirDate)?.take(4) ?: ""
    val minutes: Int? get() = runtime ?: episodeRunTime.firstOrNull()
    val imdbId: String? get() = externalIds.imdbId
    val realSeasons: List<SeasonRef> get() = seasons.filter { it.seasonNumber > 0 && it.episodeCount > 0 }

    fun trailerKey(): String? = videos.results
        .filter { it.site == "YouTube" && it.key.isNotBlank() }
        .sortedByDescending { (if (it.type == "Trailer") 2 else 0) + (if (it.official) 1 else 0) }
        .firstOrNull()?.key
}

fun img(path: String?, size: String = "w342"): String? =
    path?.let { "https://image.tmdb.org/t/p/$size$it" }

@Serializable
data class EpisodeRef(
    @SerialName("episode_number") val episodeNumber: Int,
    val name: String = "",
    val overview: String? = null,
    @SerialName("still_path") val stillPath: String? = null
)

@Serializable
data class SeasonDetail(val episodes: List<EpisodeRef> = emptyList())
