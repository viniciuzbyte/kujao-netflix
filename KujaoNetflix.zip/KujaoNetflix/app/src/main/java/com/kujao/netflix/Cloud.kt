package com.kujao.netflix

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

@Serializable
data class Session(
    val access: String,
    val refresh: String,
    val expiresAtMs: Long,
    val userId: String,
    val email: String
)

@Serializable
data class UserProfile(
    val id: String,
    val email: String,
    val name: String,
    val avatarIdx: Int = 0,
    val avatarB64: String? = null,
    val nameChangedMs: Long = 0L
)

@Serializable
data class HistoryEntry(
    val type: String,
    val id: Int,
    val season: Int = 0,
    val episode: Int = 0,
    val title: String = "",
    val poster: String? = null,
    val positionSec: Int = 0,
    val durationSec: Int = 0,
    val finished: Boolean = false,
    val updatedMs: Long = 0L
) {
    val key: String get() = "$type:$id:$season:$episode"
    val showKey: String get() = "$type:$id"
    val fraction: Float
        get() = if (durationSec > 0) (positionSec.toFloat() / durationSec).coerceIn(0f, 1f) else 0f
    val resumable: Boolean get() = !finished && positionSec >= 20
}

sealed interface DeviceStatus {
    data object Ok : DeviceStatus
    data class Banned(val untilMs: Long) : DeviceStatus
    data object Kicked : DeviceStatus
}

sealed interface ProfileResult {
    data class Done(val profile: UserProfile) : ProfileResult
    data class NameCooldown(val retryAfterSec: Long) : ProfileResult
    data object AvatarTooBig : ProfileResult
}

class CloudException(val code: Code, message: String? = null) : Exception(message) {
    enum class Code { Network, InvalidLogin, EmailUsed, WeakPass, Unauthorized, NotConfigured, ConfirmEmail, Other }
}

/**
 * Klien Supabase tipis (REST + OkHttp, tanpa SDK). Auth = Supabase Auth, semua data lewat RPC
 * yang didefinisikan di backend/supabase.sql. OkHttp bukan browser, jadi tidak kena CORS.
 */
class Cloud(private val store: Store) {
    private val base get() = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anon get() = BuildConfig.SUPABASE_ANON_KEY
    val configured: Boolean get() = base.isNotBlank() && anon.isNotBlank()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json".toMediaType()
    private val refreshLock = Mutex()

    private data class Raw(val code: Int, val body: String)

    private suspend fun raw(method: String, path: String, body: JsonElement?, bearer: String?): Raw {
        if (!configured) throw CloudException(CloudException.Code.NotConfigured)
        return withContext(Dispatchers.IO) {
            val rb = Request.Builder()
                .url(base + path)
                .header("apikey", anon)
                .header("Authorization", "Bearer ${bearer ?: anon}")
                .header("Content-Type", "application/json")
            val payload = (body?.toString() ?: "{}").toRequestBody(jsonType)
            rb.method(method, payload)
            try {
                client.newCall(rb.build()).execute().use { Raw(it.code, it.body?.string().orEmpty()) }
            } catch (e: IOException) {
                throw CloudException(CloudException.Code.Network, e.message)
            }
        }
    }

    private fun parse(s: String): JsonElement =
        runCatching { Api.json.parseToJsonElement(s) }.getOrDefault(JsonNull)

    private fun errText(body: String): String {
        val o = parse(body) as? JsonObject ?: return body.take(200)
        return listOf("msg", "message", "error_description", "error")
            .firstNotNullOfOrNull { o[it]?.jsonPrimitive?.contentOrNull } ?: body.take(200)
    }

    // ---------- auth ----------

    private fun toSession(o: JsonObject): Session? {
        val access = o["access_token"]?.jsonPrimitive?.contentOrNull ?: return null
        val refresh = o["refresh_token"]?.jsonPrimitive?.contentOrNull ?: return null
        val exp = o["expires_in"]?.jsonPrimitive?.longOrNull ?: 3600L
        val user = o["user"]?.jsonObject
        val uid = user?.get("id")?.jsonPrimitive?.contentOrNull ?: return null
        val mail = user["email"]?.jsonPrimitive?.contentOrNull.orEmpty()
        return Session(access, refresh, System.currentTimeMillis() + exp * 1000, uid, mail)
    }

    suspend fun signUp(email: String, pass: String, name: String): Session {
        val r = raw("POST", "/auth/v1/signup", buildJsonObject {
            put("email", email)
            put("password", pass)
            put("data", buildJsonObject { put("name", name) })
        }, null)
        val txt = errText(r.body).lowercase()
        if (r.code in 400..499) {
            throw when {
                "already" in txt || "registered" in txt -> CloudException(CloudException.Code.EmailUsed)
                "password" in txt -> CloudException(CloudException.Code.WeakPass)
                else -> CloudException(CloudException.Code.Other, txt)
            }
        }
        if (r.code !in 200..299) throw CloudException(CloudException.Code.Other, txt)
        val s = (parse(r.body) as? JsonObject)?.let { toSession(it) }
            ?: throw CloudException(CloudException.Code.ConfirmEmail)
        store.sessionObj = s
        return s
    }

    suspend fun signIn(email: String, pass: String): Session {
        val r = raw("POST", "/auth/v1/token?grant_type=password", buildJsonObject {
            put("email", email)
            put("password", pass)
        }, null)
        if (r.code == 400 || r.code == 401 || r.code == 422) throw CloudException(CloudException.Code.InvalidLogin)
        if (r.code !in 200..299) throw CloudException(CloudException.Code.Other, errText(r.body))
        val s = (parse(r.body) as? JsonObject)?.let { toSession(it) }
            ?: throw CloudException(CloudException.Code.Other, "bad auth response")
        store.sessionObj = s
        return s
    }

    private suspend fun refresh(old: Session): Session {
        return refreshLock.withLock {
            val cur = store.sessionObj
            // sesi mungkin sudah diperbarui oleh pemanggil lain saat menunggu lock
            if (cur != null && cur.access != old.access && cur.expiresAtMs > System.currentTimeMillis() + 30_000) {
                return@withLock cur
            }
            val r = raw("POST", "/auth/v1/token?grant_type=refresh_token", buildJsonObject {
                put("refresh_token", old.refresh)
            }, null)
            if (r.code == 400 || r.code == 401) {
                store.sessionObj = null
                throw CloudException(CloudException.Code.Unauthorized)
            }
            if (r.code !in 200..299) throw CloudException(CloudException.Code.Other, errText(r.body))
            val s = (parse(r.body) as? JsonObject)?.let { toSession(it) }
                ?: throw CloudException(CloudException.Code.Other, "bad refresh response")
            store.sessionObj = s
            s
        }
    }

    private suspend fun validSession(): Session {
        val s = store.sessionObj ?: throw CloudException(CloudException.Code.Unauthorized)
        return if (s.expiresAtMs - System.currentTimeMillis() < 60_000) refresh(s) else s
    }

    private suspend fun rpc(name: String, args: JsonObject = JsonObject(emptyMap())): JsonElement {
        var s = validSession()
        var r = raw("POST", "/rest/v1/rpc/$name", args, s.access)
        if (r.code == 401) {
            s = refresh(s)
            r = raw("POST", "/rest/v1/rpc/$name", args, s.access)
        }
        if (r.code == 401) throw CloudException(CloudException.Code.Unauthorized)
        if (r.code !in 200..299) throw CloudException(CloudException.Code.Other, errText(r.body))
        return parse(r.body)
    }

    suspend fun changePassword(newPass: String) {
        var s = validSession()
        var r = raw("PUT", "/auth/v1/user", buildJsonObject { put("password", newPass) }, s.access)
        if (r.code == 401) {
            s = refresh(s)
            r = raw("PUT", "/auth/v1/user", buildJsonObject { put("password", newPass) }, s.access)
        }
        if (r.code == 422 || r.code == 400) throw CloudException(CloudException.Code.WeakPass, errText(r.body))
        if (r.code == 401) throw CloudException(CloudException.Code.Unauthorized)
        if (r.code !in 200..299) throw CloudException(CloudException.Code.Other, errText(r.body))
    }

    // ---------- profil & device ----------

    private fun profileFrom(o: JsonObject, s: Session): UserProfile = UserProfile(
        id = s.userId,
        email = s.email,
        name = o["name"]?.jsonPrimitive?.contentOrNull.orEmpty(),
        avatarIdx = o["avatar_idx"]?.jsonPrimitive?.intOrNull ?: 0,
        avatarB64 = o["avatar_b64"]?.jsonPrimitive?.contentOrNull,
        nameChangedMs = o["name_changed_ms"]?.jsonPrimitive?.longOrNull ?: 0L
    )

    suspend fun ensureProfile(name: String): UserProfile {
        val s = validSession()
        val o = rpc("ensure_profile", buildJsonObject { put("p_name", name) }) as? JsonObject
            ?: throw CloudException(CloudException.Code.Other, "bad profile")
        return profileFrom(o, store.sessionObj ?: s)
    }

    private fun deviceFrom(e: JsonElement): DeviceStatus {
        val o = e as? JsonObject ?: return DeviceStatus.Ok
        return when (o["status"]?.jsonPrimitive?.contentOrNull) {
            "banned" -> DeviceStatus.Banned(o["until_ms"]?.jsonPrimitive?.longOrNull ?: (System.currentTimeMillis() + 3_600_000))
            "kicked" -> DeviceStatus.Kicked
            else -> DeviceStatus.Ok
        }
    }

    suspend fun claimDevice(deviceId: String): DeviceStatus =
        deviceFrom(rpc("claim_device", buildJsonObject { put("p_device", deviceId) }))

    suspend fun heartbeat(deviceId: String): DeviceStatus =
        deviceFrom(rpc("heartbeat", buildJsonObject { put("p_device", deviceId) }))

    /** Dipanggil saat logout; memakai token yang sudah ditangkap supaya tetap jalan setelah sesi dihapus. */
    suspend fun releaseDevice(session: Session?, deviceId: String) {
        val s = session ?: return
        raw("POST", "/rest/v1/rpc/release_device", buildJsonObject { put("p_device", deviceId) }, s.access)
    }

    suspend fun updateProfile(
        current: UserProfile,
        name: String,
        avatarIdx: Int,
        avatarB64: String?,
        clearAvatar: Boolean
    ): ProfileResult {
        val s = validSession()
        val e = rpc("update_profile", buildJsonObject {
            put("p_name", name)
            put("p_avatar_idx", avatarIdx)
            put("p_avatar_b64", avatarB64?.let { JsonPrimitive(it) } ?: JsonNull)
            put("p_clear_avatar", clearAvatar)
        }) as? JsonObject ?: throw CloudException(CloudException.Code.Other, "bad response")
        if (e["ok"]?.jsonPrimitive?.booleanOrNull == true) {
            val p = e["profile"] as? JsonObject ?: throw CloudException(CloudException.Code.Other, "bad profile")
            return ProfileResult.Done(profileFrom(p, store.sessionObj ?: s).copy(email = current.email))
        }
        return when (e["error"]?.jsonPrimitive?.contentOrNull) {
            "name_cooldown" -> ProfileResult.NameCooldown(e["retry_after_s"]?.jsonPrimitive?.longOrNull ?: 86_400L)
            "avatar_too_big" -> ProfileResult.AvatarTooBig
            else -> throw CloudException(CloudException.Code.Other, "update failed")
        }
    }

    // ---------- riwayat ----------

    suspend fun saveProgress(e: HistoryEntry, deviceId: String): DeviceStatus =
        deviceFrom(rpc("save_progress", buildJsonObject {
            put("p_device", deviceId)
            put("p_type", e.type)
            put("p_id", e.id)
            put("p_season", e.season)
            put("p_episode", e.episode)
            put("p_title", e.title)
            put("p_poster", e.poster?.let { JsonPrimitive(it) } ?: JsonNull)
            put("p_pos", e.positionSec)
            put("p_dur", e.durationSec)
        }))

    suspend fun fetchHistory(): List<HistoryEntry> {
        val arr = rpc("get_history") as? JsonArray ?: return emptyList()
        return arr.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            HistoryEntry(
                type = o["type"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null,
                id = o["id"]?.jsonPrimitive?.intOrNull ?: return@mapNotNull null,
                season = o["season"]?.jsonPrimitive?.intOrNull ?: 0,
                episode = o["episode"]?.jsonPrimitive?.intOrNull ?: 0,
                title = o["title"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                poster = o["poster"]?.jsonPrimitive?.contentOrNull,
                positionSec = o["position_sec"]?.jsonPrimitive?.intOrNull ?: 0,
                durationSec = o["duration_sec"]?.jsonPrimitive?.intOrNull ?: 0,
                finished = o["finished"]?.jsonPrimitive?.booleanOrNull ?: false,
                updatedMs = o["updated_ms"]?.jsonPrimitive?.longOrNull ?: 0L
            )
        }
    }

    suspend fun deleteHistory(e: HistoryEntry) {
        rpc("delete_history_item", buildJsonObject {
            put("p_type", e.type)
            put("p_id", e.id)
            put("p_season", e.season)
            put("p_episode", e.episode)
        })
    }
}

fun isCancellation(e: Throwable) = e is CancellationException
