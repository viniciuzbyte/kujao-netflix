package com.kujao.netflix

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

@Serializable
data class Asset(
    val name: String = "",
    @SerialName("browser_download_url") val url: String = ""
)

@Serializable
data class Release(
    @SerialName("tag_name") val tag: String = "",
    val name: String? = null,
    val body: String? = null,
    @SerialName("html_url") val page: String = "",
    val assets: List<Asset> = emptyList()
) {
    val apk: String get() = assets.firstOrNull { it.name.endsWith(".apk") }?.url ?: page
}

object Updater {
    private val client = OkHttpClient()

    suspend fun latest(): Release? = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url("https://api.github.com/repos/${BuildConfig.GITHUB_REPO}/releases/latest")
                .header("Accept", "application/vnd.github+json")
                .build()
            client.newCall(req).execute().use {
                if (!it.isSuccessful) null else Api.json.decodeFromString<Release>(it.body?.string() ?: return@use null)
            }
        }.getOrNull()
    }

    fun isNewer(tag: String): Boolean {
        fun parts(s: String) = s.trim().removePrefix("v").split(".")
            .map { p -> p.takeWhile { c -> c.isDigit() }.toIntOrNull() ?: 0 }
        val a = parts(tag)
        val b = parts(BuildConfig.VERSION_NAME)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    fun open(ctx: Context, r: Release) {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(r.apk)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val r = Updater.latest() ?: return Result.success()
        val store = Store(applicationContext)
        if (!Updater.isNewer(r.tag) || store.lastNotified == r.tag) return Result.success()
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("update", "Updates", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val pi = PendingIntent.getActivity(
            applicationContext, 0,
            Intent(Intent.ACTION_VIEW, Uri.parse(r.apk)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(applicationContext, "update")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Kujao Netflix ${r.tag}")
            .setContentText((r.name ?: r.tag).take(80))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
        store.lastNotified = r.tag
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<UpdateWorker>(6, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("update", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
