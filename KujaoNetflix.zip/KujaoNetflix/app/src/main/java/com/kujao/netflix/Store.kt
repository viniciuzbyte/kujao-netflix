package com.kujao.netflix

import android.content.Context
import android.util.Base64
import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

@Serializable
data class User(
    val email: String,
    val name: String,
    val salt: String,
    val hash: String,
    val avatar: Int = 0
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("kujao", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }

    var countryCode: String?
        get() = p.getString("country", null)
        set(v) { p.edit().putString("country", v).apply() }

    var themeMode: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }

    var session: String?
        get() = p.getString("session", null)
        set(v) { p.edit().putString("session", v).apply() }

    var lastNotified: String?
        get() = p.getString("notified", null)
        set(v) { p.edit().putString("notified", v).apply() }

    private fun users(): List<User> = runCatching {
        json.decodeFromString<List<User>>(p.getString("users", "[]").orEmpty())
    }.getOrDefault(emptyList())

    private fun save(list: List<User>) {
        p.edit().putString("users", json.encodeToString(list)).apply()
    }

    private fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.NO_WRAP)
    }

    private fun hash(pass: String, salt: String): ByteArray {
        val spec = PBEKeySpec(pass.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), 20000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun matches(pass: String, salt: String, expected: String): Boolean {
        val stored = runCatching { Base64.decode(expected, Base64.NO_WRAP) }.getOrNull() ?: return false
        return MessageDigest.isEqual(stored, hash(pass, salt))
    }

    fun currentUser(): User? = session?.let { e -> users().firstOrNull { it.email == e } }

    fun register(name: String, email: String, pass: String): K? {
        val e = email.trim().lowercase()
        if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) return K.ErrEmail
        if (pass.length < 6) return K.ErrPass
        val list = users()
        if (list.any { it.email == e }) return K.ErrUsed
        val salt = newSalt()
        val display = name.trim().ifBlank { e.substringBefore("@") }
        save(list + User(e, display, salt, hash(pass, salt)))
        session = e
        return null
    }

    fun login(email: String, pass: String): K? {
        val e = email.trim().lowercase()
        val u = users().firstOrNull { it.email == e }
        if (u == null || !matches(pass, u.salt, u.hash)) return K.ErrLogin
        session = e
        return null
    }

    fun update(name: String, avatar: Int, newPass: String): K? {
        val u = currentUser() ?: return null
        if (newPass.isNotEmpty() && newPass.length < 6) return K.ErrPass
        var nu = u.copy(
            name = name.trim().take(40).ifBlank { u.name },
            avatar = avatar.coerceIn(0, 7)
        )
        if (newPass.isNotEmpty()) {
            val salt = newSalt()
            nu = nu.copy(salt = salt, hash = hash(newPass, salt))
        }
        save(users().map { if (it.email == u.email) nu else it })
        return null
    }
}

class AppState(val store: Store) {
    var country by mutableStateOf(Countries.byCode(store.countryCode))
    var user by mutableStateOf(store.currentUser())
    var theme by mutableIntStateOf(store.themeMode)
    var tab by mutableIntStateOf(0)
    var filter by mutableStateOf("all")
    var update by mutableStateOf<Release?>(null)
    val home = HomeData()

    fun changeCountry(c: Country) {
        store.countryCode = c.code
        country = c
    }

    fun changeTheme(m: Int) {
        store.themeMode = m
        theme = m
    }

    fun login(email: String, pass: String): K? {
        val e = store.login(email, pass)
        user = store.currentUser()
        return e
    }

    fun register(name: String, email: String, pass: String): K? {
        val e = store.register(name, email, pass)
        user = store.currentUser()
        return e
    }

    fun updateProfile(name: String, avatar: Int, pass: String): K? {
        val e = store.update(name, avatar, pass)
        user = store.currentUser()
        return e
    }

    fun logout() {
        store.session = null
        user = null
        tab = 0
    }
}
