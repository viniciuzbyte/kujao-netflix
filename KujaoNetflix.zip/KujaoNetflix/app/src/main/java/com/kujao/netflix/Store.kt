package com.kujao.netflix

import android.content.Context
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

@Serializable
data class Health(val okMs: Long = 0L, val failMs: Long = 0L, val fails: Int = 0)

class Store(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val p = appCtx.getSharedPreferences("kujao", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }

    var countryCode: String?
        get() = p.getString("country", null)
        set(v) { p.edit().putString("country", v).apply() }

    var themeMode: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }

    var lastNotified: String?
        get() = p.getString("notified", null)
        set(v) { p.edit().putString("notified", v).apply() }

    /** ID perangkat untuk aturan 1 akun 1 device. ANDROID_ID bertahan setelah clear data/install ulang. */
    val deviceId: String by lazy {
        val saved = p.getString("device_id", null)
        if (saved != null) saved else {
            val aid = runCatching {
                Settings.Secure.getString(appCtx.contentResolver, Settings.Secure.ANDROID_ID)
            }.getOrNull()
            val id = if (!aid.isNullOrBlank() && aid != "9774d56d682e549c") "a-$aid" else "r-${UUID.randomUUID()}"
            p.edit().putString("device_id", id).apply()
            id
        }
    }

    var sessionObj: Session?
        get() = p.getString("session_json", null)?.let { runCatching { json.decodeFromString<Session>(it) }.getOrNull() }
        set(v) { p.edit().apply { if (v == null) remove("session_json") else putString("session_json", json.encodeToString(v)) }.apply() }

    var cachedProfile: UserProfile?
        get() = p.getString("profile_json", null)?.let { runCatching { json.decodeFromString<UserProfile>(it) }.getOrNull() }
        set(v) { p.edit().apply { if (v == null) remove("profile_json") else putString("profile_json", json.encodeToString(v)) }.apply() }

    var bannedUntilMs: Long
        get() = p.getLong("banned_until", 0L)
        set(v) { p.edit().putLong("banned_until", v).apply() }

    // ---- riwayat (cache lokal, per akun) ----
    private fun historyKey(uid: String) = "history_$uid"

    fun history(uid: String?): List<HistoryEntry> {
        if (uid == null) return emptyList()
        return runCatching {
            json.decodeFromString<List<HistoryEntry>>(p.getString(historyKey(uid), "[]").orEmpty())
        }.getOrDefault(emptyList())
    }

    fun saveHistory(uid: String, list: List<HistoryEntry>) {
        p.edit().putString(historyKey(uid), json.encodeToString(list.take(100))).apply()
    }

    // ---- kesehatan server ----
    fun health(): Map<String, Health> = runCatching {
        json.decodeFromString<Map<String, Health>>(p.getString("server_health", "{}").orEmpty())
    }.getOrDefault(emptyMap())

    private fun saveHealth(m: Map<String, Health>) {
        p.edit().putString("server_health", json.encodeToString(m)).apply()
    }

    fun markServerOk(id: String) {
        val m = health().toMutableMap()
        m[id] = Health(okMs = System.currentTimeMillis(), failMs = m[id]?.failMs ?: 0L, fails = 0)
        saveHealth(m)
    }

    fun markServerFail(id: String) {
        val m = health().toMutableMap()
        val old = m[id] ?: Health()
        m[id] = old.copy(failMs = System.currentTimeMillis(), fails = old.fails + 1)
        saveHealth(m)
    }

    fun clearServerFails() {
        saveHealth(health().mapValues { it.value.copy(failMs = 0L, fails = 0) })
    }

    var serversJson: String?
        get() = p.getString("servers_json", null)
        set(v) { p.edit().putString("servers_json", v).apply() }
}

class AppState(val store: Store) {
    val cloud = Cloud(store)
    /** Untuk kerja yang harus lanjut walau layar ditutup (simpan progres, release device). */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    var country by mutableStateOf(Countries.byCode(store.countryCode))
    var user by mutableStateOf(if (store.sessionObj != null) store.cachedProfile else null)
    var theme by mutableIntStateOf(store.themeMode)
    var tab by mutableIntStateOf(0)
    var filter by mutableStateOf("all")
    var update by mutableStateOf<Release?>(null)
    val home = HomeData()

    var bannedUntilMs by mutableLongStateOf(store.bannedUntilMs)
    var notice by mutableStateOf<K?>(null)
    var history by mutableStateOf(store.history(store.sessionObj?.userId))
    var resumePrompt by mutableStateOf<HistoryEntry?>(null)
    private var promptShown = false

    val isBanned: Boolean get() = bannedUntilMs > System.currentTimeMillis()

    fun changeCountry(c: Country) {
        store.countryCode = c.code
        country = c
    }

    fun changeTheme(m: Int) {
        store.themeMode = m
        theme = m
    }

    // ---------- auth ----------

    private fun errKey(e: CloudException): K = when (e.code) {
        CloudException.Code.Network -> K.ErrNetwork
        CloudException.Code.InvalidLogin -> K.ErrLogin
        CloudException.Code.EmailUsed -> K.ErrUsed
        CloudException.Code.WeakPass -> K.ErrPass
        CloudException.Code.NotConfigured -> K.ErrConfig
        CloudException.Code.ConfirmEmail -> K.ErrConfirm
        CloudException.Code.Unauthorized -> K.SessionExpired
        CloudException.Code.Other -> K.ErrGeneric
    }

    suspend fun login(email: String, pass: String): K? {
        val e = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) return K.ErrEmail
        return try {
            cloud.signIn(e, pass)
            afterAuth("")
        } catch (ex: CloudException) {
            errKey(ex)
        }
    }

    suspend fun register(name: String, email: String, pass: String): K? {
        val e = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) return K.ErrEmail
        if (pass.length < 6) return K.ErrPass
        return try {
            cloud.signUp(e, pass, name.trim())
            afterAuth(name.trim())
        } catch (ex: CloudException) {
            errKey(ex)
        }
    }

    private suspend fun afterAuth(name: String): K? {
        return try {
            val prof = cloud.ensureProfile(name)
            store.cachedProfile = prof
            user = prof
            notice = null
            history = store.history(prof.id)
            applyDevice(cloud.claimDevice(store.deviceId))
            if (!isBanned) syncHistory()
            null
        } catch (ex: CloudException) {
            if (ex.code == CloudException.Code.Unauthorized || ex.code == CloudException.Code.NotConfigured) {
                store.sessionObj = null
            }
            errKey(ex)
        }
    }

    /** Dipanggil saat app dibuka dengan sesi tersimpan. Jaringan mati = tetap pakai cache. */
    suspend fun bootstrap() {
        if (store.sessionObj == null) return
        try {
            val prof = cloud.ensureProfile(user?.name.orEmpty())
            store.cachedProfile = prof
            user = prof
            applyDevice(cloud.claimDevice(store.deviceId))
            if (!isBanned) syncHistory()
        } catch (ex: CloudException) {
            if (ex.code == CloudException.Code.Unauthorized) forceLogout(K.SessionExpired)
        }
    }

    suspend fun heartbeat() {
        if (store.sessionObj == null) return
        try {
            applyDevice(cloud.heartbeat(store.deviceId))
        } catch (ex: CloudException) {
            if (ex.code == CloudException.Code.Unauthorized) forceLogout(K.SessionExpired)
        }
    }

    fun applyDevice(st: DeviceStatus) {
        when (st) {
            DeviceStatus.Ok -> {
                store.bannedUntilMs = 0L
                bannedUntilMs = 0L
            }
            is DeviceStatus.Banned -> {
                store.bannedUntilMs = st.untilMs
                bannedUntilMs = st.untilMs
            }
            DeviceStatus.Kicked -> forceLogout(K.KickedOut)
        }
    }

    fun forceLogout(why: K?) {
        store.sessionObj = null
        store.cachedProfile = null
        user = null
        history = emptyList()
        resumePrompt = null
        promptShown = false
        tab = 0
        notice = why
    }

    fun logout() {
        val s = store.sessionObj
        val dev = store.deviceId
        scope.launch { runCatching { cloud.releaseDevice(s, dev) } }
        forceLogout(null)
    }

    // ---------- profil ----------

    suspend fun updateProfile(name: String, avatarIdx: Int, avatarB64: String?, clearAvatar: Boolean): ProfileResult? {
        val cur = user ?: return null
        val r = cloud.updateProfile(cur, name, avatarIdx, avatarB64, clearAvatar)
        if (r is ProfileResult.Done) {
            store.cachedProfile = r.profile
            user = r.profile
        }
        return r
    }

    suspend fun changePassword(newPass: String): K? {
        if (newPass.length < 6) return K.ErrPass
        return try {
            cloud.changePassword(newPass)
            null
        } catch (ex: CloudException) {
            errKey(ex)
        }
    }

    // ---------- riwayat ----------

    private fun merge(local: List<HistoryEntry>, remote: List<HistoryEntry>): List<HistoryEntry> =
        (local + remote)
            .groupBy { it.key }
            .map { (_, v) -> v.maxBy { it.updatedMs } }
            .sortedByDescending { it.updatedMs }
            .take(100)

    suspend fun syncHistory() {
        val uid = user?.id ?: return
        try {
            val merged = merge(store.history(uid), cloud.fetchHistory())
            store.saveHistory(uid, merged)
            history = merged
            maybePrompt()
        } catch (ex: CloudException) {
            if (ex.code == CloudException.Code.Unauthorized) forceLogout(K.SessionExpired)
            maybePrompt()
        }
    }

    fun recordProgress(e: HistoryEntry, pushCloud: Boolean) {
        val uid = user?.id ?: return
        val list = (listOf(e) + history.filterNot { it.key == e.key }).take(100)
        history = list
        store.saveHistory(uid, list)
        if (pushCloud) {
            val dev = store.deviceId
            scope.launch {
                try {
                    applyDevice(cloud.saveProgress(e, dev))
                } catch (_: CloudException) {
                    // offline: tersimpan lokal, akan digabung saat sync berikutnya
                }
            }
        }
    }

    fun removeHistory(e: HistoryEntry) {
        val uid = user?.id ?: return
        val list = history.filterNot { it.key == e.key }
        history = list
        store.saveHistory(uid, list)
        scope.launch { runCatching { cloud.deleteHistory(e) } }
    }

    val continueList: List<HistoryEntry>
        get() = history.groupBy { it.showKey }
            .map { (_, v) -> v.maxBy { it.updatedMs } }
            .filter { it.resumable }
            .sortedByDescending { it.updatedMs }

    private fun maybePrompt() {
        if (promptShown) return
        val e = continueList.firstOrNull() ?: return
        promptShown = true
        resumePrompt = e
    }
}
