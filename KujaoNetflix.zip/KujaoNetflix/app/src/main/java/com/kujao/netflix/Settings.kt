package com.kujao.netflix

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(app: AppState) {
    val scope = rememberCoroutineScope()
    val lang = LocalLang.current
    var pick by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 120.dp)
    ) {
        Text(tr(K.Settings), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(tr(K.Theme), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        listOf(1 to K.Light, 2 to K.Dark, 0 to K.System).forEach { (m, k) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { app.setTheme(m) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = app.theme == m,
                    onClick = { app.setTheme(m) },
                    colors = RadioButtonDefaults.colors(selectedColor = Red)
                )
                Text(tr(k))
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(tr(K.Language), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { pick = true },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            val c = app.country
            Text("${c?.flag.orEmpty()}  ${c?.name.orEmpty()}")
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "${tr(K.Version)} ${BuildConfig.VERSION_NAME}",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                scope.launch {
                    busy = true
                    status = null
                    val r = Updater.latest()
                    if (r != null && Updater.isNewer(r.tag)) {
                        app.update = r
                    } else {
                        status = I18n.t(lang, K.UpToDate)
                    }
                    busy = false
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
        ) { Text(tr(K.CheckUpdate), fontWeight = FontWeight.Bold) }
        status?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (pick) {
        AlertDialog(
            onDismissRequest = { pick = false },
            confirmButton = {},
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(Countries.all) { c ->
                        Text(
                            "${c.flag}  ${c.name}",
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    app.setCountry(c)
                                    pick = false
                                }
                                .padding(14.dp),
                            fontWeight = if (app.country == c) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        )
    }
}

@Composable
fun UpdateGate(app: AppState) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        val r = Updater.latest()
        if (r != null && Updater.isNewer(r.tag)) app.update = r
    }
    val r = app.update ?: return
    AlertDialog(
        onDismissRequest = { app.update = null },
        title = { Text("${tr(K.UpdateTitle)} ${r.tag}") },
        text = { Text((r.body ?: r.name ?: "").take(400)) },
        confirmButton = {
            TextButton({
                Updater.open(ctx, r)
                app.update = null
            }) { Text(tr(K.UpdateNow), color = Red, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton({ app.update = null }) { Text(tr(K.Later)) } }
    )
}
