package com.kujao.netflix

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

val Avatars = listOf(
    Color(0xFFE50914), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFB8C00),
    Color(0xFF8E24AA), Color(0xFF00ACC1), Color(0xFFD81B60), Color(0xFF6D4C41)
)

private const val AVATAR_PX = 192
private const val AVATAR_MAX_BYTES = 80_000

/** Potong persegi dari tengah, kecilkan ke 192px, JPEG -> base64. Null = gagal dibaca / terlalu besar. */
suspend fun prepareAvatar(ctx: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
    try {
        val cr = ctx.contentResolver
        val bmp: Bitmap = if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(cr, uri)) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                var sample = 1
                while (info.size.width / sample > 768 || info.size.height / sample > 768) sample *= 2
                dec.setTargetSampleSize(sample)
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 768 || bounds.outHeight / sample > 768) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@withContext null
        }
        val side = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(square, AVATAR_PX, AVATAR_PX, true)
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 82, bos)
        val bytes = bos.toByteArray()
        if (bytes.size > AVATAR_MAX_BYTES) null else Base64.encodeToString(bytes, Base64.NO_WRAP)
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        null
    }
}

@Composable
fun AvatarView(u: UserProfile, size: Dp, modifier: Modifier = Modifier) {
    val photo = remember(u.avatarB64) {
        u.avatarB64?.let {
            runCatching {
                val b = Base64.decode(it, Base64.NO_WRAP)
                BitmapFactory.decodeByteArray(b, 0, b.size)?.asImageBitmap()
            }.getOrNull()
        }
    }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Avatars[u.avatarIdx.coerceIn(0, Avatars.lastIndex)]),
        contentAlignment = Alignment.Center
    ) {
        if (photo != null) {
            Image(photo, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                u.name.trim().firstOrNull()?.uppercase() ?: "?",
                color = Color.White,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .liquidGlass(RoundedCornerShape(16.dp), 1.dp)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun watchedLabel(totalSec: Int): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    return if (h > 0) "${h}j ${m}m" else "${m}m"
}

@Composable
private fun HistoryRow(e: HistoryEntry, onOpen: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = img(e.poster, "w185"),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .width(56.dp)
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (e.type == "tv") {
                Text("S${e.season} · E${e.episode}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(6.dp))
            if (e.finished) {
                Text(tr(K.Finished), fontSize = 12.sp, color = Color(0xFF43A047), fontWeight = FontWeight.SemiBold)
            } else {
                LinearProgressIndicator(
                    progress = { e.fraction },
                    modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                    color = Red,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (e.durationSec > 0) "${fmtTime(e.positionSec)} / ${fmtTime(e.durationSec)}" else fmtTime(e.positionSec),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        IconButton(onDelete) {
            Icon(Icons.Filled.Close, tr(K.Delete), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

fun playRoute(e: HistoryEntry, fromStart: Boolean = false): Route.Player = Route.Player(
    type = e.type,
    id = e.id,
    title = e.title,
    season = if (e.type == "tv") e.season.coerceAtLeast(1) else null,
    episode = if (e.type == "tv") e.episode.coerceAtLeast(1) else null,
    startSec = if (fromStart) 0 else e.positionSec.coerceAtLeast(0),
    poster = e.poster
)

@Composable
fun ProfileScreen(app: AppState, nav: (Route) -> Unit) {
    val u = app.user ?: return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember(u.id) { mutableStateOf(u.name) }
    var avatar by remember(u.id) { mutableIntStateOf(u.avatarIdx) }
    var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var msgOk by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val cooldownSec = ((u.nameChangedMs + 24L * 3600_000L - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
    val nameLocked = cooldownSec > 0

    val lang = LocalLang.current
    fun t(k: K) = I18n.t(lang, k)
    fun fail(k: K) { msg = t(k); msgOk = false }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b64 = prepareAvatar(ctx, uri)
            if (b64 == null) {
                fail(K.ErrPhoto)
            } else {
                try {
                    when (app.updateProfile("", avatar, b64, false)) {
                        is ProfileResult.AvatarTooBig -> fail(K.ErrPhoto)
                        else -> { msg = null }
                    }
                } catch (_: CloudException) {
                    fail(K.ErrNetwork)
                }
            }
        }
    }

    val rows = remember(app.history) {
        app.history.sortedByDescending { it.updatedMs }
    }
    val titlesWatched = remember(app.history) { app.history.map { it.showKey }.toSet().size }
    val totalSec = remember(app.history) { app.history.sumOf { it.positionSec } }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 120.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.clickable {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) {
                    AvatarView(u.copy(avatarIdx = avatar), 104.dp)
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Red)
                            .border(2.dp, MaterialTheme.colorScheme.background, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.PhotoCamera, tr(K.ChangePhoto), tint = Color.White, modifier = Modifier.size(18.dp)) }
                }
                Spacer(Modifier.height(12.dp))
                Text(u.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(u.email, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (u.avatarB64 != null) {
                    TextButton(onClick = {
                        scope.launch {
                            try { app.updateProfile("", avatar, null, true) } catch (_: CloudException) { fail(K.ErrNetwork) }
                        }
                    }) { Text(tr(K.RemovePhoto), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Avatars.forEachIndexed { i, c ->
                            Box(
                                Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(if (i == avatar) 2.dp else 0.dp, MaterialTheme.colorScheme.onBackground, CircleShape)
                                    .clickable { avatar = i }
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(titlesWatched.toString(), tr(K.WatchedCount), Modifier.weight(1f))
                StatCard(watchedLabel(totalSec), tr(K.WatchedTime), Modifier.weight(1f))
            }
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                name, { name = it; msg = null },
                label = { Text(tr(K.Name)) },
                enabled = !nameLocked,
                singleLine = true,
                supportingText = {
                    Text(
                        if (nameLocked) "${tr(K.NameCooldown)} ${fmtTime(cooldownSec.toInt())}" else tr(K.NameOnce)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                pass, { pass = it; msg = null },
                label = { Text(tr(K.NewPass)) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            msg?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = if (msgOk) Color(0xFF43A047) else MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    if (busy) return@Button
                    busy = true
                    scope.launch {
                        try {
                            val nameToSend = if (nameLocked) "" else name
                            when (val r = app.updateProfile(nameToSend, avatar, null, false)) {
                                is ProfileResult.NameCooldown -> {
                                    msg = "${t(K.NameCooldown)} ${fmtTime(r.retryAfterSec.toInt())}"
                                    msgOk = false
                                }
                                is ProfileResult.AvatarTooBig -> fail(K.ErrPhoto)
                                else -> {
                                    val pk = if (pass.isNotEmpty()) app.changePassword(pass) else null
                                    if (pk != null) {
                                        fail(pk)
                                    } else {
                                        msg = t(K.Saved)
                                        msgOk = true
                                        pass = ""
                                    }
                                }
                            }
                        } catch (_: CloudException) {
                            fail(K.ErrNetwork)
                        }
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(tr(K.Save), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(28.dp))
            Text(tr(K.History), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            if (rows.isEmpty()) {
                Text(
                    tr(K.NoHistory),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            }
        }
        items(rows, key = { it.key }) { e ->
            HistoryRow(
                e,
                onOpen = {
                    if (e.resumable) nav(playRoute(e)) else nav(Route.Detail(e.type, e.id))
                },
                onDelete = { app.removeHistory(e) }
            )
        }
        item {
            Spacer(Modifier.height(24.dp))
            OutlinedButton(
                onClick = { app.logout() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(8.dp)
            ) { Text(tr(K.Logout)) }
        }
    }
}
