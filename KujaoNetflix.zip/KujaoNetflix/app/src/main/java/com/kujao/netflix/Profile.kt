package com.kujao.netflix

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Avatars = listOf(
    Color(0xFFE50914), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFB8C00),
    Color(0xFF8E24AA), Color(0xFF00ACC1), Color(0xFFD81B60), Color(0xFF6D4C41)
)

@Composable
fun ProfileScreen(app: AppState) {
    val u = app.user ?: return
    var name by remember(u.email) { mutableStateOf(u.name) }
    var avatar by remember(u.email) { mutableIntStateOf(u.avatar) }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<K?>(null) }
    var saved by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 120.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Avatars[avatar.coerceIn(0, Avatars.lastIndex)]),
            contentAlignment = Alignment.Center
        ) {
            Text(
                name.trim().firstOrNull()?.uppercase() ?: "?",
                color = Color.White,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Avatars.forEachIndexed { i, c ->
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(c)
                        .border(if (i == avatar) 2.dp else 0.dp, MaterialTheme.colorScheme.onBackground, CircleShape)
                        .clickable { avatar = i; saved = false }
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            name, { name = it; saved = false },
            label = { Text(tr(K.Name)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            u.email, {},
            label = { Text(tr(K.Email)) },
            enabled = false,
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            pass, { pass = it; saved = false },
            label = { Text(tr(K.NewPass)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        err?.let {
            Spacer(Modifier.height(8.dp))
            Text(tr(it), color = MaterialTheme.colorScheme.error)
        }
        if (saved) {
            Spacer(Modifier.height(8.dp))
            Text(tr(K.Saved), color = Color(0xFF43A047))
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                err = app.updateProfile(name, avatar, pass)
                saved = err == null
                if (saved) pass = ""
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
        ) { Text(tr(K.Save), fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { app.logout() },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(8.dp)
        ) { Text(tr(K.Logout)) }
    }
}
