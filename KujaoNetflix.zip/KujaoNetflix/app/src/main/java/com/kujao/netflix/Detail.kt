package com.kujao.netflix

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException

@Composable
fun DetailScreen(type: String, id: Int, tag: String, pop: () -> Unit, nav: (Route) -> Unit) {
    var retry by remember(type, id) { mutableIntStateOf(0) }
    val res by produceState<Result<Detail>?>(null, type, id, tag, retry) {
        value = try {
            Result.success(Api.detail(type, id, tag))
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Result.failure(error)
        }
    }
    val rec by produceState(emptyList<Item>(), type, id, tag) {
        value = try {
            Api.recs(type, id, tag).map { it.copy(mediaType = type) }
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            emptyList()
        }
    }
    val x = res?.getOrNull()
    if (x == null) {
        Box(Modifier.fillMaxSize()) {
            if (res == null) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Red)
            } else {
                Button(
                    onClick = { retry++ },
                    modifier = Modifier.align(Alignment.Center),
                    colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                ) {
                    Text(tr(K.Retry))
                }
            }
            IconButton(pop, Modifier.statusBarsPadding()) { Icon(Icons.Filled.ArrowBack, null) }
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(280.dp)) {
                AsyncImage(
                    model = img(x.backdropPath ?: x.posterPath, "w780"),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                            )
                        )
                )
                IconButton(
                    pop,
                    Modifier
                        .statusBarsPadding()
                        .padding(8.dp)
                        .background(Color(0x66000000), CircleShape)
                ) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(x.label, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(6.dp))
                val meta = listOfNotNull(
                    x.year.ifBlank { null },
                    x.minutes?.let { "${it}m" },
                    "★ ${"%.1f".format(x.voteAverage)}"
                ).joinToString("  ·  ")
                Text(meta, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { nav(Route.Player(type, id, x.label)) },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text(tr(K.Play), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.height(14.dp))
                if (!x.tagline.isNullOrBlank()) {
                    Text(x.tagline, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                }
                Text(x.overview.orEmpty(), lineHeight = 21.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    x.genres.joinToString("  ·  ") { it.name },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        }
        if (rec.isNotEmpty()) {
            item {
                Text(
                    tr(K.Similar),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(rec) { it ->
                        Poster(it, Modifier.width(112.dp)) { nav(Route.Detail(it.type, it.id)) }
                    }
                }
            }
        }
    }
}
