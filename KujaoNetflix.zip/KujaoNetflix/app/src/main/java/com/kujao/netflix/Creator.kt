package com.kujao.netflix

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun Reveal(delayMs: Int, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        on = true
    }
    AnimatedVisibility(
        visible = on,
        enter = fadeIn(tween(550)) + slideInVertically(tween(550)) { it / 3 }
    ) { content() }
}

@Composable
fun CreatorScreen() {
    val ctx = LocalContext.current
    val inf = rememberInfiniteTransition(label = "creator")
    val pulse by inf.animateFloat(
        1f, 1.1f,
        infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val glow by inf.animateFloat(
        0.25f, 0.75f,
        infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "glow"
    )
    val bounce by inf.animateFloat(
        0f, -8f,
        infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bounce"
    )
    val wa = Color(0xFF25D366)
    val go = Color(0xFF00ADD8)
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(start = 24.dp, end = 24.dp, bottom = 100.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Reveal(0) {
            Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(150.dp)
                        .scale(pulse)
                        .alpha(glow)
                        .background(Brush.radialGradient(listOf(go, Color.Transparent)), CircleShape)
                )
                Box(
                    Modifier
                        .size(110.dp)
                        .scale(pulse * 0.96f)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(go, Red))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("F", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Reveal(250) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("faddlan", fontSize = 32.sp, fontWeight = FontWeight.Black)
                Text("Golang lover", color = go, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(36.dp))
        Reveal(500) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Have Issue In App?", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Contact Me If You Can",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Reveal(750) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(wa.copy(alpha = 0.18f))
                    .clickable {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/6285136130069"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .offset(y = bounce.dp)
                        .clip(CircleShape)
                        .background(wa),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painterResource(R.drawable.ic_whatsapp),
                        contentDescription = "WhatsApp",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Text("wa.me/6285136130069", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }
}
