package com.kujao.netflix

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class EmbedServer(
    val id: String,
    val label: String,
    val imdbRequired: Boolean = false,
    val startParam: String? = null,
    val tvOk: Boolean = true,
    val build: (tmdbId: Int, imdbId: String?, season: Int?, episode: Int?) -> String
)

@Serializable
data class RemoteServer(
    val id: String,
    val label: String = "",
    val movie: String = "",
    val tv: String = "",
    val imdb: Boolean = false,
    val startParam: String? = null,
    val enabled: Boolean = true
)

object Servers {
    private const val UA = "Mozilla/5.0 (Android 14; Mobile; rv:160.0) Gecko/160.0 Firefox/160.0"

    private val builtin: List<EmbedServer> = listOf(
        EmbedServer("flaxmovies", "FlaxMovies") { u, _, s, e ->
            if (s != null) "https://flaxmovies.xyz/embed/tv/$u/$s/$e" else "https://flaxmovies.xyz/embed/movie/$u"
        },
        EmbedServer("vidking", "VidKing", startParam = "progress") { u, _, s, e ->
            if (s != null) "https://www.vidking.net/embed/tv/$u/$s/$e" else "https://www.vidking.net/embed/movie/$u"
        },
        EmbedServer("videasy", "VidEasy", startParam = "progress") { u, _, s, e ->
            if (s != null) "https://player.videasy.net/tv/$u/$s/$e" else "https://player.videasy.net/movie/$u"
        },
        EmbedServer("vidlink", "VidLink", startParam = "startAt") { u, _, s, e ->
            if (s != null) "https://vidlink.pro/tv/$u/$s/$e" else "https://vidlink.pro/movie/$u"
        },
        EmbedServer("vidfast", "VidFast", startParam = "startAt") { u, _, s, e ->
            if (s != null) "https://vidfast.vc/tv/$u/$s/$e" else "https://vidfast.vc/movie/$u"
        },
        EmbedServer("cinezo", "Cinezo") { u, _, s, e ->
            if (s != null) "https://player.cinezo.live/embed/tv/$u/$s/$e" else "https://player.cinezo.live/embed/movie/$u"
        },
        EmbedServer("vidsrcsu", "VidSrc.su") { u, _, s, e ->
            val base = if (s != null) "https://vidsrc.su/tv/$u/$s/$e" else "https://vidsrc.su/movie/$u"
            "$base?autoplay=true&colour=E50914&backbutton=https://vidsrc.su/&logo=https://vidsrc.su/logo.png"
        },
        EmbedServer("vidzee", "VidZee") { u, _, s, e ->
            if (s != null) "https://player.vidzee.wtf/embed/tv/$u/$s/$e" else "https://player.vidzee.wtf/embed/movie/$u"
        },
        EmbedServer("111movies", "111Movies") { u, _, s, e ->
            if (s != null) "https://111movies.com/tv/$u/$s/$e" else "https://111movies.com/movie/$u"
        },
        EmbedServer("moviesapi", "MoviesAPI") { u, _, s, e ->
            if (s != null) "https://moviesapi.to/tv/$u-$s-$e" else "https://moviesapi.to/movie/$u"
        },
        EmbedServer("cinesrc", "CineSrc") { u, _, s, e ->
            if (s != null) "https://cinesrc.st/embed/tv/$u?s=$s&e=$e" else "https://cinesrc.st/embed/movie/$u"
        },
        EmbedServer("autoembed", "AutoEmbed") { u, _, s, e ->
            if (s != null) "https://player.autoembed.cc/embed/tv/$u/$s/$e" else "https://player.autoembed.cc/embed/movie/$u"
        },
        EmbedServer("vidsrc-embed", "VidSrc Embed", imdbRequired = true) { _, o, s, e ->
            if (s != null) "https://vidsrc-embed.ru/embed/tv/$o-$s-$e" else "https://vidsrc-embed.ru/embed/movie/$o"
        },
        EmbedServer("vidsrc", "VidSrc") { u, _, s, e ->
            if (s != null) "https://vidsrc.to/embed/tv/$u/$s/$e" else "https://vidsrc.to/embed/movie/$u"
        },
        EmbedServer("mapple", "Mapple") { u, _, s, e ->
            if (s != null) "https://mapple.uk/watch/tv/$u-$s-$e" else "https://mapple.uk/watch/movie/$u"
        },
        EmbedServer("primesrc", "PrimeSrc", imdbRequired = true) { u, o, s, e ->
            if (s != null) "https://primesrc.me/embed/tv?imdb=$o&season=$s&episode=$e" else "https://primesrc.me/embed/movie?tmdb=$u"
        },
        EmbedServer("2embed", "2Embed") { u, _, s, e ->
            if (s != null) "https://www.2embed.cc/embedtv/$u&s=$s&e=$e" else "https://www.2embed.cc/embed/$u"
        },
        EmbedServer("multiembed", "MultiEmbed") { u, _, s, e ->
            "https://multiembed.mov/?video_id=$u&tmdb=1" + if (s != null) "&s=$s&e=$e" else ""
        },
        EmbedServer("vixsrc", "VixSrc") { u, _, s, e ->
            if (s != null) "https://vixsrc.to/tv/$u/$s/$e" else "https://vixsrc.to/movie/$u"
        },
        EmbedServer("vidlove", "VidLove") { u, _, s, e ->
            if (s != null) "https://player.vidlove.cc/embed/tv/$u/$s/$e" else "https://player.vidlove.cc/embed/movie/$u"
        },
        EmbedServer("filmu", "Filmu") { u, _, s, e ->
            if (s != null) "https://embed.filmu.in/tv/$u/$s/$e" else "https://embed.filmu.in/movie/$u"
        },
        EmbedServer("vidcore", "VidCore") { u, _, s, e ->
            (if (s != null) "https://vidcore.net/tv/$u/$s/$e" else "https://vidcore.net/movie/$u") + "?theme=%23E50914"
        },
        EmbedServer("vaplayer", "VAPlayer") { u, _, s, e ->
            if (s != null) "https://vaplayer.ru/embed/tv/$u/$s/$e?skin=netflix&color=ff0000" else "https://vaplayer.ru/embed/movie/$u?skin=netflix&color=ff0000"
        },
        EmbedServer("vares", "Vares") { u, _, s, e ->
            if (s != null) "https://vares.app/tv/$u/$s/$e" else "https://vares.app/movie/$u"
        },
        EmbedServer("vidbolt", "VidBolt") { u, _, s, e ->
            if (s != null) "https://vidbolt.xyz/tv/$u/$s/$e" else "https://vidbolt.xyz/movie/$u"
        },
        EmbedServer("vidnest", "VidNest") { u, _, s, e ->
            if (s != null) "https://vidnest.fun/tv/$u/$s/$e" else "https://vidnest.fun/movie/$u"
        },
        EmbedServer("vidgod", "VidGod") { u, _, s, e ->
            if (s != null) "https://vidgod.net/tv/$u/$s/$e" else "https://vidgod.net/movie/$u"
        },
        EmbedServer("vidsrcme", "VidSrc.me") { u, _, s, e ->
            if (s != null) "https://vidsrc.me/embed/tv?tmdb=$u&season=$s&episode=$e" else "https://vidsrc.me/embed/movie?tmdb=$u"
        },
        EmbedServer("1embed", "1Embed") { u, _, s, e ->
            if (s != null) "https://1embed.cc/embed/tv/$u/$s/$e" else "https://1embed.cc/embed/movie/$u"
        },
        EmbedServer("peestream", "PeeStream") { u, _, s, e ->
            if (s != null) "https://peestream.in/embed/?tmdbId=$u&type=show&season=$s&episode=$e" else "https://peestream.in/embed/?tmdbId=$u&type=movie"
        }
    )

    @Volatile
    var all: List<EmbedServer> = builtin
        private set

    // ---------- daftar server yang bisa diupdate dari servers.json ----------

    private fun fromRemote(r: RemoteServer): EmbedServer = EmbedServer(
        id = r.id,
        label = r.label.ifBlank { r.id },
        imdbRequired = r.imdb,
        startParam = r.startParam?.takeIf { it.matches(Regex("[A-Za-z0-9_]{1,20}")) },
        tvOk = r.tv.isNotBlank()
    ) { u, o, s, e ->
        val template = if (s != null) r.tv else r.movie
        template
            .replace("{tmdb}", u.toString())
            .replace("{imdb}", o.orEmpty())
            .replace("{s}", s?.toString().orEmpty())
            .replace("{e}", e?.toString().orEmpty())
    }

    fun install(jsonText: String): Boolean {
        val remote = runCatching { Api.json.decodeFromString<List<RemoteServer>>(jsonText) }.getOrNull()
            ?: return false
        val disabled = remote.filter { !it.enabled }.map { it.id }.toSet()
        val usable = remote.filter { it.enabled && it.movie.startsWith("https://") && (it.tv.isBlank() || it.tv.startsWith("https://")) }
        val ids = remote.map { it.id }.toSet()
        all = usable.map(::fromRemote) + builtin.filter { it.id !in ids && it.id !in disabled }
        return true
    }

    suspend fun refresh(store: Store) {
        store.serversJson?.let { install(it) }
        val body = fetch(BuildConfig.SERVERS_URL) ?: return
        if (install(body)) store.serversJson = body
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()

    private suspend fun fetch(url: String): String? = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext null
        try {
            http.newCall(Request.Builder().url(url).header("User-Agent", UA).build()).execute().use { r ->
                if (r.isSuccessful) r.body?.string() else null
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
    }

    // ---------- pemilihan otomatis ----------

    private const val COOLDOWN_MS = 10 * 60_000L
    private const val RECENT_OK_MS = 24 * 60 * 60_000L

     */
    fun ranked(imdbId: String?, isTv: Boolean, health: Map<String, Health>, now: Long = System.currentTimeMillis()): List<EmbedServer> {
        val usable = all.filter { (!it.imdbRequired || !imdbId.isNullOrBlank()) && (!isTv || it.tvOk) }
        val cooling = { s: EmbedServer ->
            val h = health[s.id]
            h != null && h.failMs > h.okMs && now - h.failMs < COOLDOWN_MS
        }
        val ready = usable.filterNot(cooling)
        val cool = usable.filter(cooling)
        val best = ready
            .filter { (health[it.id]?.okMs ?: 0L) > now - RECENT_OK_MS }
            .maxByOrNull { health[it.id]?.okMs ?: 0L }
        return listOfNotNull(best) + ready.filter { it.id != best?.id } + cool
    }

    fun urlFor(s: EmbedServer, tmdbId: Int, imdbId: String?, season: Int?, episode: Int?, startSec: Int): String {
        val base = s.build(tmdbId, imdbId, season, episode)
        val p = s.startParam
        return if (p != null && startSec > 20) base + (if ('?' in base) "&" else "?") + "$p=$startSec" else base
    }

    private val probeClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .callTimeout(7, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun alive(url: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).header("User-Agent", UA).get().build()
            probeClient.newCall(req).execute().use { r ->
                val c = r.code
                !(c in 500..599 || c == 404 || c == 410)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }
}
