package com.kujao.netflix

data class EmbedServer(
    val id: String,
    val label: String,
    val imdbRequired: Boolean = false,
    val build: (tmdbId: Int, imdbId: String?, season: Int?, episode: Int?) -> String
)

object Servers {
    val all: List<EmbedServer> = listOf(
        EmbedServer("cinezo", "Cinezo") { u, _, s, e ->
            if (s != null) "https://player.cinezo.live/embed/tv/$u/$s/$e" else "https://player.cinezo.live/embed/movie/$u"
        },
        EmbedServer("cinesrc", "CineSrc") { u, _, s, e ->
            if (s != null) "https://cinesrc.st/embed/tv/$u?s=$s&e=$e" else "https://cinesrc.st/embed/movie/$u"
        },
        EmbedServer("peestream", "PeeStream") { u, _, s, e ->
            if (s != null) "https://peestream.in/embed/?tmdbId=$u&type=show&season=$s&episode=$e" else "https://peestream.in/embed/?tmdbId=$u&type=movie"
        },
        EmbedServer("flaxmovies", "FlaxMovies") { u, _, s, e ->
            if (s != null) "https://flaxmovies.xyz/embed/tv/$u/$s/$e" else "https://flaxmovies.xyz/embed/movie/$u"
        },
        EmbedServer("moviesapi", "MoviesAPI") { u, _, s, e ->
            if (s != null) "https://moviesapi.to/tv/$u-$s-$e" else "https://moviesapi.to/movie/$u"
        },
        EmbedServer("vidlink", "VidLink") { u, _, s, e ->
            if (s != null) "https://vidlink.pro/tv/$u/$s/$e" else "https://vidlink.pro/movie/$u"
        },
        EmbedServer("vidsrc-embed", "VidSrc Embed", imdbRequired = true) { _, o, s, e ->
            if (s != null) "https://vidsrc-embed.ru/embed/tv/$o-$s-$e" else "https://vidsrc-embed.ru/embed/movie/$o"
        },
        EmbedServer("videasy", "VidEasy") { u, _, s, e ->
            if (s != null) "https://player.videasy.net/tv/$u/$s/$e" else "https://player.videasy.net/movie/$u"
        },
        EmbedServer("111movies", "111Movies") { u, _, s, e ->
            if (s != null) "https://111movies.com/tv/$u/$s/$e" else "https://111movies.com/movie/$u"
        },
        EmbedServer("vidzee", "VidZee") { u, _, s, e ->
            if (s != null) "https://player.vidzee.wtf/embed/tv/$u/$s/$e" else "https://player.vidzee.wtf/embed/movie/$u"
        },
        EmbedServer("vidsrc", "VidSrc") { u, _, s, e ->
            if (s != null) "https://vidsrc.to/embed/tv/$u/$s/$e" else "https://vidsrc.to/embed/movie/$u"
        },
        EmbedServer("2embed", "2Embed") { u, _, s, e ->
            if (s != null) "https://www.2embed.cc/embedtv/$u&s=$s&e=$e" else "https://www.2embed.cc/embed/$u"
        },
        EmbedServer("mapple", "Mapple") { u, _, s, e ->
            if (s != null) "https://mapple.uk/watch/tv/$u-$s-$e" else "https://mapple.uk/watch/movie/$u"
        },
        EmbedServer("primesrc", "PrimeSrc", imdbRequired = true) { u, o, s, e ->
            if (s != null) "https://primesrc.me/embed/tv?imdb=$o&season=$s&episode=$e" else "https://primesrc.me/embed/movie?tmdb=$u"
        },
        EmbedServer("multiembed", "MultiEmbed") { u, _, s, e ->
            "https://multiembed.mov/?video_id=$u&tmdb=1" + if (s != null) "&s=$s&e=$e" else ""
        },
        EmbedServer("autoembed", "AutoEmbed") { u, _, s, e ->
            if (s != null) "https://player.autoembed.cc/embed/tv/$u/$s/$e" else "https://player.autoembed.cc/embed/movie/$u"
        },
        EmbedServer("vixsrc", "VixSrc") { u, _, s, e ->
            if (s != null) "https://vixsrc.to/tv/$u/$s/$e" else "https://vixsrc.to/movie/$u"
        },
        EmbedServer("vidlove", "VidLove") { u, _, s, e ->
            if (s != null) "https://player.vidlove.cc/embed/tv/$u/$s/$e" else "https://player.vidlove.cc/embed/movie/$u"
        },
        EmbedServer("vidfast", "VidFast") { u, _, s, e ->
            if (s != null) "https://vidfast.vc/tv/$u/$s/$e" else "https://vidfast.vc/movie/$u"
        },
        EmbedServer("filmu", "Filmu") { u, _, s, e ->
            if (s != null) "https://embed.filmu.in/tv/$u/$s/$e" else "https://embed.filmu.in/movie/$u"
        },
        EmbedServer("vidcore", "VidCore") { u, _, s, e ->
            (if (s != null) "https://vidcore.net/tv/$u/$s/$e" else "https://vidcore.net/movie/$u") + "?theme=%23E50914"
        },
        EmbedServer("vaplayer", "VAPlayer") { u, _, s, e ->
            if (s != null) "https://vaplayer.ru/embed/tv/$u/$s/$e?skin=netflix&color=ff0000" else "https://vaplayer.ru/embed/movie/$u?skin=netflix&color=ff0000"
        },
        EmbedServer("vares", "Vares") { u, _, s, e ->
            if (s != null) "https://vares.app/tv/$u/$s/$e" else "https://vares.app/movie/$u"
        },
        EmbedServer("vidking", "VidKing") { u, _, s, e ->
            if (s != null) "https://www.vidking.net/embed/tv/$u/$s/$e" else "https://www.vidking.net/embed/movie/$u"
        },
        EmbedServer("vidbolt", "VidBolt") { u, _, s, e ->
            if (s != null) "https://vidbolt.xyz/tv/$u/$s/$e" else "https://vidbolt.xyz/movie/$u"
        },
        EmbedServer("vidnest", "VidNest") { u, _, s, e ->
            if (s != null) "https://vidnest.fun/tv/$u/$s/$e" else "https://vidnest.fun/movie/$u"
        },
        EmbedServer("vidsrcsu", "VidSrc.su") { u, _, s, e ->
            val base = if (s != null) "https://vidsrc.su/tv/$u/$s/$e" else "https://vidsrc.su/movie/$u"
            "$base?autoplay=true&colour=E50914&backbutton=https://vidsrc.su/&logo=https://vidsrc.su/logo.png"
        },
        EmbedServer("vidgod", "VidGod") { u, _, s, e ->
            if (s != null) "https://vidgod.net/tv/$u/$s/$e" else "https://vidgod.net/movie/$u"
        },
        EmbedServer("vidsrcme", "VidSrc.me") { u, _, s, e ->
            if (s != null) "https://vidsrc.me/embed/tv?tmdb=$u&season=$s&episode=$e" else "https://vidsrc.me/embed/movie?tmdb=$u"
        },
        EmbedServer("1embed", "1Embed") { u, _, s, e ->
            if (s != null) "https://1embed.cc/embed/tv/$u/$s/$e" else "https://1embed.cc/embed/movie/$u"
        }
    )

    val default: EmbedServer get() = all.first()

    fun usable(imdbId: String?): List<EmbedServer> =
        all.filter { !it.imdbRequired || !imdbId.isNullOrBlank() }

    fun byId(id: String): EmbedServer? = all.firstOrNull { it.id == id }
}
