package com.kujao.netflix

enum class K {
    Home, Search, Profile, Settings, Creator, Welcome, ChooseCountry, Continue, Login, Register,
    Email, Password, Name, HaveAccount, NoAccount, Play, SearchHint, Popular, Similar, Save,
    Logout, Theme, Dark, Light, System, UpdateTitle, UpdateNow, Later, NoResult, Minimize,
    Language, Version, ErrEmail, ErrPass, ErrUsed, ErrLogin, Retry, CheckUpdate, UpToDate, Saved,
    All, Movies, Series, NoTrailer, NewPass,
    Server, Servers, Season, Episode, NextEpisode, PrevEpisode, EmbedFailed, SwitchServer, Loading,
    // ---- teks baru (en & id; bahasa lain otomatis pakai en) ----
    ErrNetwork, ErrConfig, ErrConfirm, ErrGeneric, KickedOut, SessionExpired, BannedTitle, BannedBody,
    BannedLeft, ChangePhoto, RemovePhoto, NameCooldown, NameOnce, History, ContinueWatching, Resume,
    Close, ResumeAsk, StartOver, ErrPhoto, Delete, NoHistory, FindingServer, AllFailed, WatchedCount,
    WatchedTime, Finished, PlayFromStart, Episodes
}

object I18n {
    private val tables: Map<String, List<String>> = mapOf(
        "en" to ("Home|Search|Profile|Settings|Creator|Welcome to Kujao Netflix|Choose your country|Continue|Sign in|Create account|" +
            "Email|Password|Name|Already have an account? Sign in|New here? Create account|Play|Search movies & series|Popular|More like this|Save|" +
            "Sign out|Theme|Dark|Light|System|Update available|Update|Later|Nothing found|Minimize|" +
            "Language|Version|Invalid email|Password needs 6+ characters|Email already registered|Wrong email or password|Retry|Check for updates|You are on the latest version|Saved|" +
            "All|Movies|Series|No trailer available|New password (optional)|" +
            "Server|Servers|Season|Episode|Next episode|Previous episode|This server failed to load|Switch server|Loading").split("|"),
        "id" to ("Beranda|Cari|Profil|Pengaturan|Kreator|Selamat datang di Kujao Netflix|Pilih negaramu|Lanjut|Masuk|Buat akun|" +
            "Email|Kata sandi|Nama|Sudah punya akun? Masuk|Belum punya akun? Daftar|Putar|Cari film & serial|Populer|Lainnya seperti ini|Simpan|" +
            "Keluar|Tema|Gelap|Terang|Sistem|Pembaruan tersedia|Perbarui|Nanti|Tidak ditemukan|Perkecil|" +
            "Bahasa|Versi|Email tidak valid|Kata sandi minimal 6 karakter|Email sudah terdaftar|Email atau kata sandi salah|Coba lagi|Cek pembaruan|Kamu sudah di versi terbaru|Tersimpan|" +
            "Semua|Film|Serial|Trailer tidak tersedia|Kata sandi baru (opsional)|" +
            "Server|Server|Musim|Episode|Episode berikutnya|Episode sebelumnya|Server ini gagal dimuat|Ganti server|Memuat").split("|"),
        "es" to ("Inicio|Buscar|Perfil|Ajustes|Creador|Bienvenido a Kujao Netflix|Elige tu país|Continuar|Iniciar sesión|Crear cuenta|" +
            "Correo|Contraseña|Nombre|¿Ya tienes cuenta? Inicia sesión|¿Nuevo? Crea una cuenta|Reproducir|Buscar películas y series|Populares|Más como esto|Guardar|" +
            "Cerrar sesión|Tema|Oscuro|Claro|Sistema|Actualización disponible|Actualizar|Luego|Sin resultados|Minimizar|" +
            "Idioma|Versión|Correo no válido|La contraseña necesita 6+ caracteres|Correo ya registrado|Correo o contraseña incorrectos|Reintentar|Buscar actualizaciones|Tienes la última versión|Guardado|" +
            "Todo|Películas|Series|Sin tráiler disponible|Nueva contraseña (opcional)|" +
            "Servidor|Servidores|Temporada|Episodio|Siguiente episodio|Episodio anterior|Este servidor falló al cargar|Cambiar servidor|Cargando").split("|"),
        "ja" to ("ホーム|検索|プロフィール|設定|クリエイター|Kujao Netflixへようこそ|国を選択|続ける|ログイン|アカウント作成|" +
            "メール|パスワード|名前|アカウントをお持ちですか？ログイン|初めてですか？アカウント作成|再生|映画・シリーズを検索|人気|関連作品|保存|" +
            "ログアウト|テーマ|ダーク|ライト|システム|アップデートあり|更新|後で|見つかりません|最小化|" +
            "言語|バージョン|メールが無効です|パスワードは6文字以上|登録済みのメールです|メールまたはパスワードが違います|再試行|更新を確認|最新バージョンです|保存しました|" +
            "すべて|映画|シリーズ|予告編なし|新しいパスワード（任意）|" +
            "サーバー|サーバー|シーズン|エピソード|次のエピソード|前のエピソード|このサーバーは読み込みに失敗しました|サーバーを切り替え|読み込み中").split("|"),
        "ko" to ("홈|검색|프로필|설정|크리에이터|Kujao Netflix에 오신 것을 환영합니다|국가를 선택하세요|계속|로그인|계정 만들기|" +
            "이메일|비밀번호|이름|이미 계정이 있나요? 로그인|처음이세요? 계정 만들기|재생|영화·시리즈 검색|인기|비슷한 콘텐츠|저장|" +
            "로그아웃|테마|다크|라이트|시스템|업데이트 가능|업데이트|나중에|결과 없음|최소화|" +
            "언어|버전|잘못된 이메일|비밀번호는 6자 이상|이미 등록된 이메일|이메일 또는 비밀번호가 틀렸습니다|다시 시도|업데이트 확인|최신 버전입니다|저장됨|" +
            "전체|영화|시리즈|예고편 없음|새 비밀번호(선택)|" +
            "서버|서버|시즌|에피소드|다음 에피소드|이전 에피소드|이 서버는 로드에 실패했습니다|서버 전환|불러오는 중").split("|")
    )

    private val baseCount = K.Loading.ordinal + 1

    private val extra: Map<String, List<String>> = mapOf(
        "en" to ("No connection. Check your internet.|Account backend is not configured|" +
            "Email confirmation is still on in the backend, turn it off|Something went wrong|" +
            "Your account is now active on another device|Session expired, please sign in again|" +
            "Access paused|This account is already active on another device. 1 account = 1 device.|" +
            "Try again in|Change photo|Remove photo|You can change your name again in|" +
            "Name can be changed once every 24 hours|Watch history|Continue watching|Resume|" +
            "Dismiss|Continue watching|Start over|This photo can't be used|Remove|Nothing watched yet|" +
            "Finding the best server…|No server could play this right now|Titles watched|Time watched|" +
            "Finished|Play from start|Episodes").split("|"),
        "id" to ("Tidak ada koneksi. Cek internetmu.|Backend akun belum dikonfigurasi|" +
            "Konfirmasi email masih aktif di backend, matikan dulu|Terjadi kesalahan|" +
            "Akunmu sedang aktif di perangkat lain|Sesi habis, silakan masuk lagi|" +
            "Akses dijeda|Akun ini sedang dipakai di perangkat lain. 1 akun hanya untuk 1 perangkat.|" +
            "Coba lagi dalam|Ganti foto|Hapus foto|Nama bisa diganti lagi dalam|" +
            "Nama hanya bisa diganti 1x per 24 jam|Riwayat tontonan|Lanjutkan menonton|Lanjutkan|" +
            "Tutup|Lanjut nonton|Mulai dari awal|Foto ini tidak bisa dipakai|Hapus|Belum ada tontonan|" +
            "Mencari server terbaik…|Belum ada server yang bisa memutar ini|Judul ditonton|Waktu menonton|" +
            "Selesai|Putar dari awal|Episode").split("|")
    )

    fun t(lang: String, k: K): String {
        val i = k.ordinal
        if (i < baseCount) return (tables[lang] ?: tables.getValue("en")).getOrElse(i) { k.name }
        return extra[lang]?.getOrNull(i - baseCount)
            ?: extra.getValue("en").getOrElse(i - baseCount) { k.name }
    }
}

data class Country(val code: String, val name: String, val flag: String, val tag: String, val ui: String)

object Countries {
    val all = listOf(
        Country("ID", "Indonesia", "🇮🇩", "id-ID", "id"),
        Country("US", "United States", "🇺🇸", "en-US", "en"),
        Country("GB", "United Kingdom", "🇬🇧", "en-GB", "en"),
        Country("MY", "Malaysia", "🇲🇾", "ms-MY", "en"),
        Country("SG", "Singapore", "🇸🇬", "en-SG", "en"),
        Country("PH", "Philippines", "🇵🇭", "en-PH", "en"),
        Country("IN", "India", "🇮🇳", "hi-IN", "en"),
        Country("JP", "日本", "🇯🇵", "ja-JP", "ja"),
        Country("KR", "대한민국", "🇰🇷", "ko-KR", "ko"),
        Country("ES", "España", "🇪🇸", "es-ES", "es"),
        Country("MX", "México", "🇲🇽", "es-MX", "es"),
        Country("BR", "Brasil", "🇧🇷", "pt-BR", "en"),
        Country("TH", "ไทย", "🇹🇭", "th-TH", "en"),
        Country("VN", "Việt Nam", "🇻🇳", "vi-VN", "en"),
        Country("DE", "Deutschland", "🇩🇪", "de-DE", "en"),
        Country("FR", "France", "🇫🇷", "fr-FR", "en"),
        Country("TR", "Türkiye", "🇹🇷", "tr-TR", "en"),
        Country("SA", "السعودية", "🇸🇦", "ar-SA", "en")
    )

    fun byCode(code: String?): Country? = all.firstOrNull { it.code == code }
}
