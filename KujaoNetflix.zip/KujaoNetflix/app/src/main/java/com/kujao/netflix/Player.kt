package com.kujao.netflix

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private fun ytHtml(key: String): String =
    "<html><body style=\"margin:0;background:#000\"><iframe style=\"position:absolute;inset:0;width:100%;height:100%;border:0\" " +
        "src=\"https://www.youtube-nocookie.com/embed/$key?autoplay=1&playsinline=1&rel=0&modestbranding=1\" " +
        "allow=\"autoplay; fullscreen; picture-in-picture\" allowfullscreen></iframe></body></html>"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebEmbed(url: String? = null, html: String? = null) {
    AndroidView(
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()
                setBackgroundColor(android.graphics.Color.BLACK)
                if (url != null) {
                    loadUrl(url)
                } else {
                    loadDataWithBaseURL("https://www.youtube-nocookie.com", html.orEmpty(), "text/html", "utf-8", null)
                }
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { it.destroy() }
    )
}

@Composable
fun ExoView(url: String) {
    val ctx = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                setShowNextButton(false)
                setShowPreviousButton(false)
            }
        },
        update = { it.useController = !Pip.inPip },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun PlayerScreen(type: String, id: Int, title: String, tag: String, back: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var full by remember { mutableStateOf(false) }
    val lightBg = MaterialTheme.colorScheme.background.luminance() > 0.5f
    val template = remember(type, id) {
        BuildConfig.EMBED_TEMPLATE.replace("{type}", type).replace("{id}", id.toString())
    }
    val trailer by produceState<String?>("", type, id) {
        value = if (template.isNotBlank()) null else runCatching {
            Api.detail(type, id, tag).trailerKey()
        }.getOrNull()
    }

    DisposableEffect(Unit) {
        Pip.wantsPip = true
        val w = act?.window
        val ic = if (w != null) WindowCompat.getInsetsController(w, w.decorView) else null
        ic?.isAppearanceLightStatusBars = false
        onDispose {
            Pip.wantsPip = false
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ic?.show(WindowInsetsCompat.Type.systemBars())
            ic?.isAppearanceLightStatusBars = lightBg
        }
    }

    LaunchedEffect(full) {
        val a = act ?: return@LaunchedEffect
        a.requestedOrientation = if (full) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val ic = WindowCompat.getInsetsController(a.window, a.window.decorView)
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (full) ic.hide(WindowInsetsCompat.Type.systemBars()) else ic.show(WindowInsetsCompat.Type.systemBars())
    }

    BackHandler(full) { full = false }

    val wide = full || Pip.inPip
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(if (wide) Modifier else Modifier.statusBarsPadding())
    ) {
        Box(
            if (wide) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        ) {
            val t = trailer
            when {
                template.contains(".m3u8") || template.contains(".mp4") -> ExoView(template)
                template.isNotBlank() -> WebEmbed(url = template)
                t == "" -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Red)
                t != null -> WebEmbed(html = ytHtml(t))
                else -> Text(tr(K.NoTrailer), Modifier.align(Alignment.Center), color = Color.White)
            }
            if (!Pip.inPip) {
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton({ if (full) full = false else back() }) {
                        Icon(Icons.Filled.ArrowBack, null, tint = Color.White)
                    }
                    Text(
                        title,
                        Modifier.weight(1f),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton({ act?.enterPip() }) {
                        Icon(Icons.Filled.PictureInPictureAlt, tr(K.Minimize), tint = Color.White)
                    }
                    IconButton({ full = !full }) {
                        Icon(
                            if (full) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            null,
                            tint = Color.White
                        )
                    }
                }
            }
        }
        if (!wide) {
            Text(
                title,
                Modifier.padding(16.dp),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
