package com.kujao.netflix

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.CancellationException
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private fun ytHtml(key: String): String =
    "<html><body style=\"margin:0;background:#000\"><iframe style=\"position:absolute;inset:0;width:100%;height:100%;border:0\" " +
        "src=\"https://www.youtube-nocookie.com/embed/$key?autoplay=1&playsinline=1&rel=0&modestbranding=1\" " +
        "allow=\"autoplay; fullscreen; picture-in-picture\" allowfullscreen></iframe></body></html>"

enum class EmbedState { LOADING, READY, FAILED }

/**
 * Script yang disuntik ke SEMUA frame (termasuk iframe lintas-origin) lewat addDocumentStartJavaScript.
 * Ia mencari <video>, melaporkan posisi/durasi/error ke native, dan seek ke START (lanjut nonton).
 * Video pendek (< 120 dtk, biasanya iklan/preview) diabaikan di sisi native.
 */
private fun trackerJs(startSec: Int): String = """
(function(){
  if (window.__kj) return; window.__kj = 1;
  var START = $startSec, seeked = false;
  function send(o){ try { KujaoBridge.postMessage(JSON.stringify(o)); } catch(e){} }
  var seen = new WeakSet();
  function seek(v){
    if (START > 20 && !seeked && isFinite(v.duration) && v.duration > START + 30) {
      if (Math.abs(v.currentTime - START) > 5) { try { v.currentTime = START; } catch(e){} }
      seeked = true;
    }
  }
  function hook(v){
    if (seen.has(v)) return; seen.add(v);
    v.addEventListener('loadedmetadata', function(){ seek(v); });
    v.addEventListener('canplay', function(){ seek(v); });
    v.addEventListener('playing', function(){ seek(v); send({t:'playing', d: Math.floor(v.duration||0)}); });
    v.addEventListener('pause', function(){ send({t:'paused'}); });
    v.addEventListener('waiting', function(){ send({t:'waiting'}); });
    v.addEventListener('error', function(){ send({t:'error', c: (v.error && v.error.code) || 0}); });
    setInterval(function(){
      if (!v.paused && isFinite(v.duration) && v.duration > 0) {
        send({t:'time', p: Math.floor(v.currentTime), d: Math.floor(v.duration)});
      }
    }, 5000);
  }
  function scan(){
    var vs = document.getElementsByTagName('video');
    for (var i = 0; i < vs.length; i++) hook(vs[i]);
  }
  try { new MutationObserver(scan).observe(document, {childList:true, subtree:true}); } catch(e){}
  document.addEventListener('DOMContentLoaded', scan);
  setInterval(scan, 2000);
})();
"""

private class EmbedFrame(ctx: android.content.Context) : FrameLayout(ctx) {
    val webView = WebView(ctx)
    var customView: View? = null
    var customCallback: WebChromeClient.CustomViewCallback? = null
    var script: ScriptHandler? = null
    var loadedKey: Any? = null
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebEmbed(
    url: String? = null,
    html: String? = null,
    key: Any? = url ?: html,
    startSec: Int = 0,
    onBridge: (String) -> Unit = {},
    onState: (EmbedState) -> Unit = {}
) {
    // Dipegang lewat array supaya closure WebView selalu memanggil callback TERBARU.
    val onStateRef = remember { arrayOf(onState) }
    onStateRef[0] = onState
    val onBridgeRef = remember { arrayOf(onBridge) }
    onBridgeRef[0] = onBridge

    AndroidView(
        factory = { c ->
            val frame = EmbedFrame(c)
            val webView = frame.webView
            webView.apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                setBackgroundColor(android.graphics.Color.BLACK)
                // Wajib hardware layer: video <video>/EME butuh surface hardware untuk tampil.
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                webViewClient = EmbedClient { onStateRef[0](it) }
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
                runCatching {
                    WebViewCompat.addWebMessageListener(webView, "KujaoBridge", setOf("*")) { _, message, _, _, _ ->
                        message.data?.let { onBridgeRef[0](it) }
                    }
                }
            }
            frame.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            // Video fullscreen (JS requestFullscreen) ditaruh di lapisan atas. Tanpa ini hanya audio yang jalan.
            webView.webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    if (frame.customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    frame.customView = view
                    frame.customCallback = callback
                    webView.visibility = View.GONE
                    view?.let {
                        frame.addView(it, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    }
                }

                override fun onHideCustomView() {
                    frame.customView?.let { frame.removeView(it) }
                    frame.customView = null
                    webView.visibility = View.VISIBLE
                    frame.customCallback?.onCustomViewHidden()
                    frame.customCallback = null
                }
            }
            frame
        },
        update = { frame ->
            if (frame.loadedKey != key) {
                frame.loadedKey = key
                frame.script?.remove()
                frame.script = null
                if (url != null && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    frame.script = runCatching {
                        WebViewCompat.addDocumentStartJavaScript(frame.webView, trackerJs(startSec), setOf("*"))
                    }.getOrNull()
                }
                if (url != null) {
                    frame.webView.loadUrl(url)
                } else {
                    frame.webView.loadDataWithBaseURL("https://www.youtube-nocookie.com", html.orEmpty(), "text/html", "utf-8", null)
                }
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { frame ->
            frame.script?.remove()
            frame.webView.destroy()
        }
    )
}

private class EmbedClient(private val onState: (EmbedState) -> Unit) : WebViewClient() {
    override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
        onState(EmbedState.LOADING)
    }

    override fun onPageFinished(view: WebView?, u: String?) {
        onState(EmbedState.READY)
    }

    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
        if (request?.isForMainFrame != false) onState(EmbedState.FAILED)
    }

    // Server hidup tapi menjawab 4xx/5xx untuk halaman utama (judul tidak ada, diblokir, down).
    override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: android.webkit.WebResourceResponse?) {
        val code = errorResponse?.statusCode ?: return
        if (request?.isForMainFrame == true && (code >= 500 || code == 404 || code == 410)) onState(EmbedState.FAILED)
    }

    override fun onReceivedSslError(view: WebView?, handler: android.webkit.SslErrorHandler?, error: android.net.http.SslError?) {
        handler?.cancel()
        onState(EmbedState.FAILED)
    }
}

@Composable
fun ExoView(url: String, onState: (EmbedState) -> Unit) {
    val ctx = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    androidx.media3.common.Player.STATE_READY -> onState(EmbedState.READY)
                    androidx.media3.common.Player.STATE_BUFFERING -> onState(EmbedState.LOADING)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                onState(EmbedState.FAILED)
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                setShowNextButton(false)
                setShowPreviousButton(false)
            }
        },
        update = { it.useController = !Pip.inPip },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun ShimmerBox(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val t by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "shimmer-t"
    )
    Box(
        modifier
            .background(Color(0xFF111111))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.08f), Color.Transparent),
                    start = Offset(t * 600f - 300f, 0f),
                    end = Offset(t * 600f, 300f)
                )
            )
    )
}

@Composable
private fun PlayerLoadingOverlay(label: String) {
    Box(Modifier.fillMaxSize()) {
        ShimmerBox(Modifier.fillMaxSize())
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Red, strokeWidth = 3.dp)
            Spacer(Modifier.height(10.dp))
            Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun GlassIconButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .liquidGlass(CircleShape, 1.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EpisodeSheet(
    seasonCount: Int,
    season: Int,
    episodesInSeason: Int,
    episode: Int,
    onPick: (season: Int, episode: Int) -> Unit,
    onDismiss: () -> Unit
) {
    var s by remember { mutableIntStateOf(season) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF141414)) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(tr(K.Season) + " & " + tr(K.Episode), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items((1..seasonCount).toList()) { n ->
                    FilterChip(
                        selected = n == s,
                        onClick = { s = n },
                        label = { Text("${tr(K.Season)} $n") }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        LazyColumn(Modifier.heightIn(max = 320.dp)) {
            val count = if (s == season) episodesInSeason else 30
            items((1..maxOf(count, 1)).toList()) { e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(s, e) }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${tr(K.Episode)} $e", color = Color.White, modifier = Modifier.weight(1f))
                    if (s == season && e == episode) Icon(Icons.Filled.Check, null, tint = Red)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}


fun fmtTime(totalSec: Int): String {
    val t = totalSec.coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val sec = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@Composable
fun PlayerScreen(app: AppState, route: Route.Player, tag: String, back: () -> Unit) {
    val type = route.type
    val id = route.id
    val title = route.title
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var full by remember { mutableStateOf(false) }
    val lightBg = MaterialTheme.colorScheme.background.luminance() > 0.5f

    val isTv = type == "tv"
    var season by remember { mutableStateOf(route.season ?: if (isTv) 1 else null) }
    var episode by remember { mutableStateOf(route.episode ?: if (isTv) 1 else null) }
    var episodesInSeason by remember { mutableStateOf(route.episodesInSeason) }
    var seasonCount by remember { mutableStateOf(1) }
    var round by remember { mutableIntStateOf(0) }

    val detail by produceState<Detail?>(null, type, id, tag) {
        value = try {
            Api.detail(type, id, tag)
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            null
        }
    }
    LaunchedEffect(detail, season) {
        val d = detail ?: return@LaunchedEffect
        if (isTv) {
            seasonCount = maxOf(d.realSeasons.size, 1)
            episodesInSeason = d.realSeasons.firstOrNull { it.seasonNumber == season }?.episodeCount ?: episodesInSeason
        }
    }

    // ---- posisi awal (lanjut nonton) ----
    fun startFor(s: Int?, e: Int?): Int {
        if (s == route.season && e == route.episode && route.startSec >= 0) return route.startSec
        val key = "$type:$id:${s ?: 0}:${e ?: 0}"
        return app.history.firstOrNull { it.key == key }?.takeIf { it.resumable }?.positionSec ?: 0
    }

    val initialStart = remember(season, episode) { startFor(season, episode) }
    var resumeAt by remember(season, episode) { mutableIntStateOf(initialStart) }
    var lastPos by remember(season, episode) { mutableIntStateOf(initialStart) }
    var lastDur by remember(season, episode) { mutableIntStateOf(0) }
    var tracked by remember(season, episode) { mutableStateOf(false) }
    var gotTime by remember(season, episode) { mutableStateOf(false) }

    // ---- pemilihan server otomatis (tanpa UI pilih server) ----
    val ranked = remember(route.imdbId, season, episode, round) {
        Servers.ranked(route.imdbId, isTv, app.store.health())
    }
    var idx by remember(season, episode, round) { mutableIntStateOf(0) }
    var exhausted by remember(season, episode, round) { mutableStateOf(false) }
    var dead by remember(season, episode, round) { mutableStateOf(setOf<String>()) }
    val server = ranked.getOrNull(idx)
    var embedState by remember(idx, season, episode, round) { mutableStateOf(EmbedState.LOADING) }
    var playingSeen by remember(idx, season, episode, round) { mutableStateOf(false) }
    var paused by remember(idx, season, episode, round) { mutableStateOf(false) }
    var waitingSince by remember(idx, season, episode, round) { mutableStateOf(0L) }
    val bridgeOk = remember {
        runCatching {
            WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) &&
                WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        }.getOrDefault(false)
    }

    val embedUrl = remember(server?.id, season, episode, resumeAt, round) {
        server?.let { Servers.urlFor(it, id, route.imdbId, season, episode, resumeAt) }
    }

    fun failover() {
        val cur = ranked.getOrNull(idx) ?: run { exhausted = true; return }
        app.store.markServerFail(cur.id)
        if (lastPos > 20) resumeAt = lastPos
        if (idx < ranked.lastIndex) idx += 1 else exhausted = true
    }

    // 1) halaman utama gagal (DNS/SSL/HTTP error)
    LaunchedEffect(embedState) { if (embedState == EmbedState.FAILED && !exhausted) failover() }
    // 2) terlalu lama tidak selesai dimuat
    LaunchedEffect(embedUrl, round) {
        delay(25_000)
        if (embedState == EmbedState.LOADING && !exhausted) failover()
    }
    // 3) cek cepat beberapa server teratas lewat OkHttp (judul tidak ada / host mati)
    LaunchedEffect(season, episode, round) {
        kotlinx.coroutines.coroutineScope {
            ranked.take(6).forEach { c ->
                launch {
                    val u = Servers.urlFor(c, id, route.imdbId, season, episode, 0)
                    if (!Servers.alive(u)) dead = dead + c.id
                }
            }
        }
    }
    LaunchedEffect(server?.id, dead) {
        val cur = server
        if (cur != null && cur.id in dead && !playingSeen && !exhausted) failover()
    }
    // 4) buffering macet > 30 dtk
    LaunchedEffect(idx, season, episode, round) {
        while (true) {
            delay(5_000)
            val w = waitingSince
            if (w > 0L && !paused && System.currentTimeMillis() - w > 30_000L && !exhausted) {
                waitingSince = 0L
                failover()
            }
        }
    }

    val onBridge: (String) -> Unit = { raw ->
        val o = runCatching { JSONObject(raw) }.getOrNull()
        if (o != null) {
            when (o.optString("t")) {
                "time" -> {
                    val d = o.optInt("d")
                    if (d >= 120) {
                        lastPos = o.optInt("p")
                        lastDur = d
                        gotTime = true
                        tracked = true
                        paused = false
                        waitingSince = 0L
                        if (!playingSeen) {
                            playingSeen = true
                            server?.let { app.store.markServerOk(it.id) }
                        }
                    }
                }
                "playing" -> if (o.optInt("d") >= 120) {
                    paused = false
                    waitingSince = 0L
                }
                "paused" -> paused = true
                "waiting" -> if (playingSeen && waitingSince == 0L) waitingSince = System.currentTimeMillis()
                "error" -> if (o.optInt("c") in 2..4 && !exhausted) failover()
            }
        }
    }

    // ---- perkiraan waktu bila WebView lama tidak mendukung jembatan JS ----
    LaunchedEffect(embedState, idx, season, episode, round) {
        if (bridgeOk || embedState != EmbedState.READY) return@LaunchedEffect
        delay(20_000)
        tracked = true
        while (true) {
            delay(1_000)
            lastPos += 1
        }
    }

    // ---- simpan riwayat ----
    fun persist(toCloud: Boolean) {
        if (!tracked || lastPos <= 0) return
        val dur = if (lastDur > 0) lastDur else (detail?.minutes?.times(60) ?: 0)
        app.recordProgress(
            HistoryEntry(
                type = type,
                id = id,
                season = season ?: 0,
                episode = episode ?: 0,
                title = title,
                poster = route.poster ?: detail?.posterPath,
                positionSec = lastPos,
                durationSec = dur,
                finished = dur > 0 && lastPos >= dur * 0.92,
                updatedMs = System.currentTimeMillis()
            ),
            toCloud
        )
    }
    LaunchedEffect(season, episode) {
        var n = 0
        while (true) {
            delay(10_000)
            n += 1
            persist(n % 3 == 0)
        }
    }
    DisposableEffect(season, episode) { onDispose { persist(true) } }

    DisposableEffect(Unit) {
        Pip.wantsPip = true
        val w = act?.window
        val ic = if (w != null) WindowCompat.getInsetsController(w, w.decorView) else null
        ic?.isAppearanceLightStatusBars = false
        onDispose {
            Pip.wantsPip = false
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ic?.show(WindowInsetsCompat.Type.systemBars())
            ic?.isAppearanceLightStatusBars = lightBg
        }
    }

    LaunchedEffect(full) {
        val a = act ?: return@LaunchedEffect
        a.requestedOrientation = if (full) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val ic = WindowCompat.getInsetsController(a.window, a.window.decorView)
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (full) ic.hide(WindowInsetsCompat.Type.systemBars()) else ic.show(WindowInsetsCompat.Type.systemBars())
    }

    BackHandler(full) { full = false }

    var showEpisodes by remember { mutableStateOf(false) }
    val wide = full || Pip.inPip
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(if (wide) Modifier else Modifier.statusBarsPadding())
    ) {
        Box(
            if (wide) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        ) {
            val u = embedUrl
            if (u != null && !exhausted) {
                if (u.contains(".m3u8") || u.contains(".mp4")) {
                    ExoView(u) { embedState = it }
                } else {
                    WebEmbed(url = u, key = "$u#$round", startSec = resumeAt, onBridge = onBridge) { embedState = it }
                }
            }
            androidx.compose.animation.AnimatedVisibility(
                visible = embedState == EmbedState.LOADING && !exhausted,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.matchParentSize()
            ) { PlayerLoadingOverlay(if (idx == 0) tr(K.Loading) else tr(K.FindingServer)) }
            if (exhausted || server == null) {
                Column(
                    Modifier.align(Alignment.Center).background(Color.Black).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(tr(K.AllFailed), color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            app.store.clearServerFails()
                            round += 1
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                    ) { Text(tr(K.Retry)) }
                }
            }
            if (!Pip.inPip) {
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton({ if (full) full = false else back() }) {
                        Icon(Icons.Filled.ArrowBack, null, tint = Color.White)
                    }
                    Text(
                        if (isTv) "$title · S${season}E${episode}" else title,
                        Modifier.weight(1f),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton({ act?.enterPip() }) {
                        Icon(Icons.Filled.PictureInPictureAlt, tr(K.Minimize), tint = Color.White)
                    }
                    IconButton({ full = !full }) {
                        Icon(
                            if (full) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            null,
                            tint = Color.White
                        )
                    }
                }
            }
            if (!Pip.inPip && isTv) {
                Row(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    GlassIconButton({
                        val cur = episode ?: 1
                        if (cur > 1) episode = cur - 1
                    }) { Icon(Icons.Filled.SkipPrevious, tr(K.PrevEpisode), tint = Color.White) }
                    GlassIconButton({ showEpisodes = true }) {
                        Text("S${season}E${episode}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    GlassIconButton({
                        val cur = episode ?: 1
                        if (episodesInSeason <= 0 || cur < episodesInSeason) episode = cur + 1
                    }) { Icon(Icons.Filled.SkipNext, tr(K.NextEpisode), tint = Color.White) }
                }
            }
        }
        if (!wide) {
            Column(Modifier.padding(16.dp)) {
                Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                val meta = listOfNotNull(
                    if (isTv) "S${season} · E${episode}" else null,
                    if (resumeAt > 20) "${tr(K.Resume)} ${fmtTime(resumeAt)}" else null
                ).joinToString("  ·  ")
                if (meta.isNotBlank()) Text(meta, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            }
        }
    }

    if (showEpisodes && isTv) {
        EpisodeSheet(
            seasonCount = seasonCount,
            season = season ?: 1,
            episodesInSeason = episodesInSeason,
            episode = episode ?: 1,
            onPick = { s, e ->
                persist(true)
                season = s
                episode = e
                showEpisodes = false
            },
            onDismiss = { showEpisodes = false }
        )
    }
}
