package com.kujao.netflix

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.CancellationException
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private fun ytHtml(key: String): String =
    "<html><body style=\"margin:0;background:#000\"><iframe style=\"position:absolute;inset:0;width:100%;height:100%;border:0\" " +
        "src=\"https://www.youtube-nocookie.com/embed/$key?autoplay=1&playsinline=1&rel=0&modestbranding=1\" " +
        "allow=\"autoplay; fullscreen; picture-in-picture\" allowfullscreen></iframe></body></html>"

enum class EmbedState { LOADING, READY, FAILED }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebEmbed(
    url: String? = null,
    html: String? = null,
    key: Any? = url ?: html,
    onState: (EmbedState) -> Unit = {}
) {
    // Dipegang lewat array (bukan val biasa) supaya closure di WebChromeClient
    // selalu memanggil callback onState TERBARU, bukan yang dibekukan saat factory jalan.
    val onStateRef = remember { arrayOf(onState) }
    onStateRef[0] = onState

    AndroidView(
        factory = { c ->
            val webView = WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                setBackgroundColor(android.graphics.Color.BLACK)
                // Wajib hardware layer: video <video>/EME butuh surface hardware untuk
                // tampil. Tanpa ini WebView kadang cuma stream audio, framenya kosong.
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                webViewClient = EmbedClient { onStateRef[0](it) }
            }
            // Root FrameLayout: WebView di lapisan bawah, video fullscreen (custom view
            // yang diminta lewat JS requestFullscreen()) ditaruh di lapisan atas.
            // Tanpa container + override onShowCustomView/onHideCustomView di bawah,
            // Chromium cuma mematikan render video saat embed minta fullscreen —
            // audio tetap jalan, video-nya kosong. Itu penyebab "suara doang" di APK.
            object : FrameLayout(c) {
                var customView: View? = null
                var customCallback: WebChromeClient.CustomViewCallback? = null

                init {
                    addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    webView.webChromeClient = object : WebChromeClient() {
                        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                            if (customView != null) {
                                callback?.onCustomViewHidden()
                                return
                            }
                            customView = view
                            customCallback = callback
                            webView.visibility = View.GONE
                            view?.let {
                                addView(it, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                            }
                        }

                        override fun onHideCustomView() {
                            customView?.let { removeView(it) }
                            customView = null
                            webView.visibility = View.VISIBLE
                            customCallback?.onCustomViewHidden()
                            customCallback = null
                        }
                    }
                    tag = webView
                }
            }
        },
        update = { frame ->
            val wv = frame.tag as WebView
            if (wv.tag != key) {
                wv.tag = key
                if (url != null) {
                    wv.loadUrl(url)
                } else {
                    wv.loadDataWithBaseURL("https://www.youtube-nocookie.com", html.orEmpty(), "text/html", "utf-8", null)
                }
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { frame -> (frame.tag as? WebView)?.destroy() }
    )
}

private class EmbedClient(private val onState: (EmbedState) -> Unit) : WebViewClient() {
    override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
        onState(EmbedState.LOADING)
    }

    override fun onPageFinished(view: WebView?, u: String?) {
        onState(EmbedState.READY)
    }

    override fun onReceivedError(
        view: WebView?,
        request: WebResourceRequest?,
        error: WebResourceError?
    ) {
        if (request?.isForMainFrame != false) onState(EmbedState.FAILED)
    }
}

@Composable
fun ExoView(url: String, onState: (EmbedState) -> Unit) {
    val ctx = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    androidx.media3.common.Player.STATE_READY -> onState(EmbedState.READY)
                    androidx.media3.common.Player.STATE_BUFFERING -> onState(EmbedState.LOADING)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                onState(EmbedState.FAILED)
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                setShowNextButton(false)
                setShowPreviousButton(false)
            }
        },
        update = { it.useController = !Pip.inPip },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun ShimmerBox(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val t by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "shimmer-t"
    )
    Box(
        modifier
            .background(Color(0xFF111111))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.08f), Color.Transparent),
                    start = Offset(t * 600f - 300f, 0f),
                    end = Offset(t * 600f, 300f)
                )
            )
    )
}

@Composable
private fun PlayerLoadingOverlay() {
    Box(Modifier.fillMaxSize()) {
        ShimmerBox(Modifier.fillMaxSize())
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Red, strokeWidth = 3.dp)
            Spacer(Modifier.height(10.dp))
            Text(tr(K.Loading), color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun GlassIconButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .liquidGlass(CircleShape, 1.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ServerSheet(
    current: EmbedServer,
    usable: List<EmbedServer>,
    onPick: (EmbedServer) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF141414)) {
        Text(
            tr(K.Servers),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        LazyColumn(Modifier.heightIn(max = 420.dp)) {
            items(usable) { s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(s) }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(s.label, color = Color.White, modifier = Modifier.weight(1f))
                    if (s.id == current.id) Icon(Icons.Filled.Check, null, tint = Red)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EpisodeSheet(
    seasonCount: Int,
    season: Int,
    episodesInSeason: Int,
    episode: Int,
    onPick: (season: Int, episode: Int) -> Unit,
    onDismiss: () -> Unit
) {
    var s by remember { mutableIntStateOf(season) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF141414)) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(tr(K.Season) + " & " + tr(K.Episode), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items((1..seasonCount).toList()) { n ->
                    FilterChip(
                        selected = n == s,
                        onClick = { s = n },
                        label = { Text("${tr(K.Season)} $n") }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        LazyColumn(Modifier.heightIn(max = 320.dp)) {
            val count = if (s == season) episodesInSeason else 30
            items((1..maxOf(count, 1)).toList()) { e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(s, e) }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${tr(K.Episode)} $e", color = Color.White, modifier = Modifier.weight(1f))
                    if (s == season && e == episode) Icon(Icons.Filled.Check, null, tint = Red)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun PlayerScreen(route: Route.Player, tag: String, back: () -> Unit, nav: (Route) -> Unit) {
    val type = route.type
    val id = route.id
    val title = route.title
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var full by remember { mutableStateOf(false) }
    val lightBg = MaterialTheme.colorScheme.background.luminance() > 0.5f

    val isTv = type == "tv"
    var season by remember { mutableStateOf(route.season ?: if (isTv) 1 else null) }
    var episode by remember { mutableStateOf(route.episode ?: if (isTv) 1 else null) }
    var episodesInSeason by remember { mutableStateOf(route.episodesInSeason) }
    var seasonCount by remember { mutableStateOf(1) }

    LaunchedEffect(type, id) {
        if (isTv) {
            try {
                val d = Api.detail(type, id, tag)
                seasonCount = maxOf(d.realSeasons.size, 1)
                if (episodesInSeason <= 0) {
                    episodesInSeason = d.realSeasons.firstOrNull { it.seasonNumber == season }?.episodeCount ?: 0
                }
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) { /* keep defaults */ }
        }
    }

    val usable = remember(route.imdbId) { Servers.usable(route.imdbId) }
    var server by remember { mutableStateOf(usable.first()) }
    var attemptIndex by remember { mutableIntStateOf(0) }
    var embedState by remember(server, season, episode) { mutableStateOf(EmbedState.LOADING) }
    var showServers by remember { mutableStateOf(false) }
    var showEpisodes by remember { mutableStateOf(false) }

    val embedUrl = remember(server, id, route.imdbId, season, episode) {
        server.build(id, route.imdbId, season, episode)
    }

    LaunchedEffect(embedState, server) {
        if (embedState == EmbedState.FAILED && attemptIndex < usable.lastIndex) {
            attemptIndex += 1
            server = usable[attemptIndex]
        }
    }

    val trailer by produceState<String?>("", type, id, tag) {
        value = try {
            Api.detail(type, id, tag).trailerKey()
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            null
        }
    }

    DisposableEffect(Unit) {
        Pip.wantsPip = true
        val w = act?.window
        val ic = if (w != null) WindowCompat.getInsetsController(w, w.decorView) else null
        ic?.isAppearanceLightStatusBars = false
        onDispose {
            Pip.wantsPip = false
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ic?.show(WindowInsetsCompat.Type.systemBars())
            ic?.isAppearanceLightStatusBars = lightBg
        }
    }

    LaunchedEffect(full) {
        val a = act ?: return@LaunchedEffect
        a.requestedOrientation = if (full) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val ic = WindowCompat.getInsetsController(a.window, a.window.decorView)
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (full) ic.hide(WindowInsetsCompat.Type.systemBars()) else ic.show(WindowInsetsCompat.Type.systemBars())
    }

    BackHandler(full) { full = false }

    val wide = full || Pip.inPip
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(if (wide) Modifier else Modifier.statusBarsPadding())
    ) {
        Box(
            if (wide) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        ) {
            val t = trailer
            when {
                embedUrl.contains(".m3u8") || embedUrl.contains(".mp4") ->
                    ExoView(embedUrl) { embedState = it }
                embedUrl.isNotBlank() ->
                    WebEmbed(url = embedUrl, key = embedUrl) { embedState = it }
                t == "" -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Red)
                t != null -> WebEmbed(html = ytHtml(t))
                else -> Text(tr(K.NoTrailer), Modifier.align(Alignment.Center), color = Color.White)
            }
            androidx.compose.animation.AnimatedVisibility(
                visible = embedState == EmbedState.LOADING,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.matchParentSize()
            ) { PlayerLoadingOverlay() }
            if (embedState == EmbedState.FAILED && attemptIndex >= usable.lastIndex) {
                Column(
                    Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(tr(K.EmbedFailed), color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { showServers = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                    ) { Text(tr(K.SwitchServer)) }
                }
            }
            if (!Pip.inPip) {
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton({ if (full) full = false else back() }) {
                        Icon(Icons.Filled.ArrowBack, null, tint = Color.White)
                    }
                    Text(
                        if (isTv) "$title · S${season}E${episode}" else title,
                        Modifier.weight(1f),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton({ act?.enterPip() }) {
                        Icon(Icons.Filled.PictureInPictureAlt, tr(K.Minimize), tint = Color.White)
                    }
                    IconButton({ full = !full }) {
                        Icon(
                            if (full) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            null,
                            tint = Color.White
                        )
                    }
                }
            }
            if (!Pip.inPip) {
                Row(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (isTv) {
                        GlassIconButton({
                            val cur = episode ?: 1
                            if (cur > 1) {
                                episode = cur - 1
                                attemptIndex = 0
                                server = usable.first()
                            }
                        }) { Icon(Icons.Filled.SkipPrevious, tr(K.PrevEpisode), tint = Color.White) }
                        GlassIconButton({ showEpisodes = true }) {
                            Text("S${season}E${episode}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        GlassIconButton({
                            val cur = episode ?: 1
                            if (episodesInSeason <= 0 || cur < episodesInSeason) {
                                episode = cur + 1
                                attemptIndex = 0
                                server = usable.first()
                            }
                        }) { Icon(Icons.Filled.SkipNext, tr(K.NextEpisode), tint = Color.White) }
                    }
                    GlassIconButton({ showServers = true }) {
                        Icon(Icons.Filled.Dns, tr(K.Server), tint = Color.White)
                    }
                }
            }
        }
        if (!wide) {
            Column(Modifier.padding(16.dp)) {
                Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Row(
                    Modifier
                        .liquidGlass(RoundedCornerShape(10.dp))
                        .clickable { showServers = true }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Dns, null, tint = Red, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(server.label, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }

    if (showServers) {
        ServerSheet(
            current = server,
            usable = usable,
            onPick = {
                server = it
                attemptIndex = usable.indexOf(it)
                showServers = false
            },
            onDismiss = { showServers = false }
        )
    }
    if (showEpisodes && isTv) {
        EpisodeSheet(
            seasonCount = seasonCount,
            season = season ?: 1,
            episodesInSeason = episodesInSeason,
            episode = episode ?: 1,
            onPick = { s, e ->
                season = s
                episode = e
                attemptIndex = 0
                server = usable.first()
                showEpisodes = false
            },
            onDismiss = { showEpisodes = false }
        )
    }
}
