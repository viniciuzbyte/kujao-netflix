package com.kujao.netflix

import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

val Red = Color(0xFFE50914)

fun Modifier.liquidGlass(shape: Shape = RoundedCornerShape(20.dp), borderWidth: Dp = 1.dp): Modifier =
    this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f))
            ),
            shape
        )
        .border(
            borderWidth,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f))
            ),
            shape
        )

private val DarkC = darkColorScheme(
    primary = Red,
    background = Color(0xFF0A0A0A),
    surface = Color(0xFF141414),
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF262626),
    onSurfaceVariant = Color(0xFFB3B3B3)
)

private val LightC = lightColorScheme(
    primary = Red,
    background = Color(0xFFF5F5F5),
    surface = Color.White,
    onBackground = Color(0xFF141414),
    onSurface = Color(0xFF141414),
    surfaceVariant = Color(0xFFE5E5E5),
    onSurfaceVariant = Color(0xFF555555)
)

fun Context.findActivity(): MainActivity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is MainActivity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun KujaoTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val view = LocalView.current
    SideEffect {
        val w = view.context.findActivity()?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkC else LightC, content = content)
}
