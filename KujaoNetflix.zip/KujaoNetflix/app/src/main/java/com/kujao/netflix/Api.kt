package com.kujao.netflix

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.decodeFromJsonElement
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

object Api {
    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
    }

    private const val BASE = "https://holaflix.cc/api/tmdb/"
    private const val ROOT = "https://holaflix.cc/"
    private const val MOVIES = "https://holaflix.cc/movies"
    private const val UA = "Mozilla/5.0 (Android 14; Mobile; rv:160.0) Gecko/160.0 Firefox/160.0"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private suspend inline fun <reified T> get(
        path: String,
        referer: String,
        vararg q: Pair<String, String>
    ): T = withContext(Dispatchers.IO) {
        val b = (BASE + path).toHttpUrl().newBuilder()
        q.forEach { b.addQueryParameter(it.first, it.second) }
        val req = Request.Builder()
            .url(b.build())
            .header("User-Agent", UA)
            .header("Referer", referer)
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body?.string() ?: throw IOException("Empty response body")
            var element = json.parseToJsonElement(body)
            val wrapper = element as? JsonObject
            if (wrapper != null && wrapper["data"] != null && wrapper["results"] == null && wrapper["id"] == null) {
                element = wrapper["data"]!!
            }
            json.decodeFromJsonElement<T>(element)
        }
    }

    suspend fun discover(type: String, lang: String, page: Int = 1, genre: Int? = null): List<Item> {
        val q = mutableListOf(
            "language" to lang,
            "page" to page.toString(),
            "sort_by" to "popularity.desc"
        )
        if (genre != null) q += "with_genres" to genre.toString()
        return get<Page>("discover/$type", MOVIES, *q.toTypedArray())
            .results.map { it.copy(mediaType = type) }
    }

    suspend fun genres(type: String, lang: String): List<Genre> =
        get<GenreList>("genre/$type/list", MOVIES, "language" to lang).genres

    suspend fun search(query: String, lang: String): List<Item> {
        val movies = try {
            get<Page>(
                "search/movie", MOVIES,
                "language" to lang, "page" to "1", "query" to query
            ).results.map { it.copy(mediaType = "movie") }
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            emptyList()
        }
        val multi = if (movies.size >= 12) emptyList() else try {
            get<Page>("search/multi", ROOT, "language" to lang, "query" to query)
                .results.filter { it.mediaType == "movie" || it.mediaType == "tv" }
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            emptyList()
        }
        return (movies + multi)
            .distinctBy { "${it.type}${it.id}" }
            .filter { it.posterPath != null }
    }

    suspend fun detail(type: String, id: Int, lang: String): Detail =
        get(
            "$type/$id", "https://holaflix.cc/details/$type/$id",
            "language" to lang,
            "append_to_response" to "external_ids,videos",
            "include_video_language" to "${lang.take(2)},en,null"
        )

    suspend fun recs(type: String, id: Int, lang: String): List<Item> =
        get<Page>("$type/$id/recommendations", "https://holaflix.cc/play/$type/$id", "language" to lang)
            .results.filter { it.posterPath != null }

    suspend fun season(id: Int, seasonNumber: Int, lang: String): List<EpisodeRef> =
        get<SeasonDetail>(
            "tv/$id/season/$seasonNumber", "https://holaflix.cc/details/tv/$id",
            "language" to lang
        ).episodes
}
