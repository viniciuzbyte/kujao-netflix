package com.kujao.netflix

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border

@Composable
fun Onboarding(app: AppState) {
    var sel by remember { mutableStateOf<Country?>(null) }
    CompositionLocalProvider(LocalLang provides (sel?.ui ?: "en")) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF3A0A0E), Color(0xFF0A0A0A)),
                        radius = 1200f
                    )
                )
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(24.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).liquidGlass(CircleShape, 1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("K", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("KUJAO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                }
                Spacer(Modifier.height(28.dp))
                Text(tr(K.Welcome), fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White, lineHeight = 36.sp)
                Spacer(Modifier.height(8.dp))
                Text(tr(K.ChooseCountry), color = Color.White.copy(alpha = 0.65f), fontSize = 15.sp)
                LazyColumn(
                    Modifier
                        .weight(1f)
                        .padding(vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(Countries.all) { c ->
                        val on = sel == c
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .liquidGlass(RoundedCornerShape(16.dp), if (on) 1.5.dp else 1.dp)
                                .then(
                                    if (on) Modifier.border(1.5.dp, Red, RoundedCornerShape(16.dp)) else Modifier
                                )
                                .clickable { sel = c }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(c.flag, fontSize = 26.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                c.name,
                                fontSize = 16.sp,
                                fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                            if (on) Icon(Icons.Filled.Check, null, tint = Red)
                        }
                    }
                }
                Button(
                    onClick = { sel?.let { app.changeCountry(it) } },
                    enabled = sel != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Red,
                        contentColor = Color.White,
                        disabledContainerColor = Color.White.copy(alpha = 0.1f)
                    )
                ) {
                    Text(tr(K.Continue), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun AuthScreen(app: AppState) {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<K?>(null) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("KUJAO", color = Red, fontSize = 40.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
        Spacer(Modifier.height(24.dp))
        Text(
            if (register) tr(K.Register) else tr(K.Login),
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(16.dp))
        if (register) {
            OutlinedTextField(
                name, { name = it },
                label = { Text(tr(K.Name)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(
            email, { email = it },
            label = { Text(tr(K.Email)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            pass, { pass = it },
            label = { Text(tr(K.Password)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        err?.let {
            Spacer(Modifier.height(8.dp))
            Text(tr(it), color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                err = if (register) app.register(name, email, pass) else app.login(email, pass)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
        ) {
            Text(if (register) tr(K.Register) else tr(K.Login), fontWeight = FontWeight.Bold)
        }
        TextButton(
            onClick = {
                register = !register
                err = null
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (register) tr(K.HaveAccount) else tr(K.NoAccount),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
