package com.kujao.netflix

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed interface Route {
    data object Main : Route
    data class Detail(val type: String, val id: Int) : Route
    data class Player(
        val type: String,
        val id: Int,
        val title: String,
        val imdbId: String? = null,
        val season: Int? = null,
        val episode: Int? = null,
        val episodesInSeason: Int = 0,
        /** -1 = otomatis dari riwayat; >= 0 = paksa mulai di detik itu */
        val startSec: Int = -1,
        val poster: String? = null
    ) : Route
}

val LocalLang = staticCompositionLocalOf { "en" }

@Composable
fun tr(k: K): String = I18n.t(LocalLang.current, k)

@Composable
fun KujaoApp(app: AppState) {
    val lang = app.country?.ui ?: "en"
    CompositionLocalProvider(LocalLang provides lang) {
        KujaoTheme(app.theme) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var stack by remember { mutableStateOf<List<Route>>(listOf(Route.Main)) }
                LaunchedEffect(app.user == null) { stack = listOf(Route.Main) }
                // daftar server bisa diperbarui dari servers.json tanpa rilis APK baru
                LaunchedEffect(Unit) { Servers.refresh(app.store) }
                // verifikasi sesi + klaim device saat app dibuka
                LaunchedEffect(app.user?.id) { if (app.user != null) app.bootstrap() }
                // heartbeat: slot device dianggap kosong kalau 3 menit tidak ada kabar
                LaunchedEffect(app.user?.id) {
                    while (app.user != null) {
                        delay(60_000)
                        app.heartbeat()
                    }
                }
                val c = app.country
                if (c == null) {
                    Onboarding(app)
                } else if (app.user == null) {
                    AuthScreen(app)
                } else if (app.isBanned) {
                    BanScreen(app)
                } else {
                    BackHandler(stack.size > 1) { stack = stack.dropLast(1) }
                    val push: (Route) -> Unit = { stack = stack + it }
                    val pop: () -> Unit = { stack = stack.dropLast(1) }
                    when (val r = stack.last()) {
                        Route.Main -> MainScreen(app, push)
                        is Route.Detail -> DetailScreen(app, r.type, r.id, c.tag, pop, push)
                        is Route.Player -> PlayerScreen(app, r, c.tag, pop)
                    }
                    UpdateGate(app)
                }
            }
        }
    }
}

@Composable
fun MainScreen(app: AppState, nav: (Route) -> Unit) {
    val tabs = listOf(
        Icons.Filled.Home to K.Home,
        Icons.Filled.Search to K.Search,
        Icons.Filled.Person to K.Profile,
        Icons.Filled.Settings to K.Settings,
        Icons.Filled.Code to K.Creator
    )
    Box(Modifier.fillMaxSize()) {
        when (app.tab) {
            0 -> HomeScreen(app, nav)
            1 -> SearchScreen(app, nav)
            2 -> ProfileScreen(app, nav)
            3 -> SettingsScreen(app)
            else -> CreatorScreen()
        }
        ResumeBanner(app, nav, Modifier.align(Alignment.TopCenter))
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .liquidGlass(RoundedCornerShape(40.dp), 1.dp)
                .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            tabs.forEachIndexed { i, (icon, k) ->
                val sel = app.tab == i
                val pillColor by animateColorAsState(
                    targetValue = if (sel) Red.copy(alpha = 0.16f) else Color.Transparent,
                    label = "nav-pill"
                )
                val scale by animateFloatAsState(
                    targetValue = if (sel) 1f else 0.9f,
                    animationSpec = spring(dampingRatio = 0.5f),
                    label = "nav-scale"
                )
                Column(
                    Modifier
                        .weight(1f)
                        .graphicsLayer { scaleX = scale; scaleY = scale }
                        .clip(RoundedCornerShape(30.dp))
                        .background(pillColor)
                        .clickable { app.tab = i }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        icon, null,
                        tint = if (sel) Red else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        tr(k),
                        fontSize = 10.sp,
                        maxLines = 1,
                        color = if (sel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
