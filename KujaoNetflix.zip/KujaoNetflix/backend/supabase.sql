create table if not exists public.profiles (
  user_id         uuid primary key references auth.users(id) on delete cascade,
  name            text not null,
  avatar_idx      int  not null default 0,
  avatar_b64      text,
  name_changed_at timestamptz,
  device_id       text,
  device_seen_at  timestamptz
);

create table if not exists public.banned_devices (
  device_id text primary key,
  until     timestamptz not null
);

create table if not exists public.watch_history (
  user_id      uuid not null references auth.users(id) on delete cascade,
  media_type   text not null check (media_type in ('movie','tv')),
  tmdb_id      int  not null,
  season       int  not null default 0,
  episode      int  not null default 0,
  title        text not null default '',
  poster_path  text,
  position_sec int  not null default 0,
  duration_sec int  not null default 0,
  finished     boolean not null default false,
  updated_at   timestamptz not null default now(),
  primary key (user_id, media_type, tmdb_id, season, episode)
);

alter table public.profiles       enable row level security;
alter table public.banned_devices enable row level security;
alter table public.watch_history  enable row level security;
-- sengaja tanpa policy: client tidak boleh baca/tulis tabel langsung.

-- ===== konstanta aturan (ubah di sini kalau mau) =====
-- slot device dianggap kosong kalau tidak ada heartbeat selama 3 menit
-- ban pelanggar: 1 jam

create or replace function public._profile_json(p public.profiles) returns jsonb
language sql immutable as $$
  select jsonb_build_object(
    'name', p.name,
    'avatar_idx', p.avatar_idx,
    'avatar_b64', p.avatar_b64,
    'name_changed_ms', coalesce((extract(epoch from p.name_changed_at) * 1000)::bigint, 0)
  )
$$;

create or replace function public.ensure_profile(p_name text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  em text;
  prof public.profiles;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  select * into prof from public.profiles where user_id = uid;
  if not found then
    select email into em from auth.users where id = uid;
    insert into public.profiles(user_id, name)
    values (uid, left(coalesce(nullif(btrim(p_name), ''), split_part(em, '@', 1)), 40))
    returning * into prof;
  end if;
  return public._profile_json(prof);
end $$;

create or replace function public.claim_device(p_device text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  prof public.profiles;
  b timestamptz;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  select until into b from public.banned_devices where device_id = p_device and until > now();
  if found then
    return jsonb_build_object('status', 'banned', 'until_ms', (extract(epoch from b) * 1000)::bigint);
  end if;

  select * into prof from public.profiles where user_id = uid for update;
  if not found then raise exception 'no profile'; end if;

  if prof.device_id is null
     or prof.device_id = p_device
     or prof.device_seen_at is null
     or prof.device_seen_at < now() - interval '3 minutes' then
    update public.profiles set device_id = p_device, device_seen_at = now() where user_id = uid;
    return jsonb_build_object('status', 'ok');
  end if;

  -- slot masih dipakai device lain -> pelanggaran: device ini kena ban 1 jam
  b := now() + interval '1 hour';
  insert into public.banned_devices(device_id, until) values (p_device, b)
  on conflict (device_id) do update set until = excluded.until;
  return jsonb_build_object('status', 'banned', 'until_ms', (extract(epoch from b) * 1000)::bigint);
end $$;

create or replace function public.heartbeat(p_device text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  prof public.profiles;
  b timestamptz;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  select until into b from public.banned_devices where device_id = p_device and until > now();
  if found then
    return jsonb_build_object('status', 'banned', 'until_ms', (extract(epoch from b) * 1000)::bigint);
  end if;
  select * into prof from public.profiles where user_id = uid for update;
  if not found or prof.device_id is distinct from p_device then
    return jsonb_build_object('status', 'kicked');
  end if;
  update public.profiles set device_seen_at = now() where user_id = uid;
  return jsonb_build_object('status', 'ok');
end $$;

create or replace function public.release_device(p_device text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set device_id = null, device_seen_at = null
  where user_id = auth.uid() and device_id = p_device;
end $$;

create or replace function public.update_profile(
  p_name text, p_avatar_idx int, p_avatar_b64 text, p_clear_avatar boolean
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  prof public.profiles;
  new_name text := left(btrim(coalesce(p_name, '')), 40);
  wait_s bigint;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  select * into prof from public.profiles where user_id = uid for update;
  if not found then raise exception 'no profile'; end if;

  if new_name <> '' and new_name <> prof.name then
    if prof.name_changed_at is not null and prof.name_changed_at > now() - interval '24 hours' then
      wait_s := ceil(extract(epoch from (prof.name_changed_at + interval '24 hours' - now())));
      return jsonb_build_object('ok', false, 'error', 'name_cooldown', 'retry_after_s', wait_s);
    end if;
    prof.name := new_name;
    prof.name_changed_at := now();
  end if;

  if p_clear_avatar then
    prof.avatar_b64 := null;
  elsif p_avatar_b64 is not null then
    if length(p_avatar_b64) > 120000 then
      return jsonb_build_object('ok', false, 'error', 'avatar_too_big');
    end if;
    prof.avatar_b64 := p_avatar_b64;
  end if;
  if p_avatar_idx is not null then prof.avatar_idx := greatest(0, least(p_avatar_idx, 7)); end if;

  update public.profiles
     set name = prof.name, name_changed_at = prof.name_changed_at,
         avatar_b64 = prof.avatar_b64, avatar_idx = prof.avatar_idx
   where user_id = uid;
  return jsonb_build_object('ok', true, 'profile', public._profile_json(prof));
end $$;

-- hanya device yang memegang slot yang boleh menulis progres
create or replace function public.save_progress(
  p_device text, p_type text, p_id int, p_season int, p_episode int,
  p_title text, p_poster text, p_pos int, p_dur int
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  holder text;
  fin boolean;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  select device_id into holder from public.profiles where user_id = uid;
  if holder is distinct from p_device then
    return jsonb_build_object('status', 'kicked');
  end if;
  fin := p_dur > 0 and p_pos >= (p_dur * 0.92);
  insert into public.watch_history(user_id, media_type, tmdb_id, season, episode,
      title, poster_path, position_sec, duration_sec, finished, updated_at)
  values (uid, p_type, p_id, coalesce(p_season, 0), coalesce(p_episode, 0),
      left(coalesce(p_title, ''), 200), p_poster, greatest(p_pos, 0), greatest(p_dur, 0), fin, now())
  on conflict (user_id, media_type, tmdb_id, season, episode) do update
     set title = excluded.title, poster_path = excluded.poster_path,
         position_sec = excluded.position_sec, duration_sec = excluded.duration_sec,
         finished = excluded.finished, updated_at = now();
  return jsonb_build_object('status', 'ok');
end $$;

create or replace function public.get_history() returns jsonb
language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'type', media_type, 'id', tmdb_id, 'season', season, 'episode', episode,
      'title', title, 'poster', poster_path, 'position_sec', position_sec,
      'duration_sec', duration_sec, 'finished', finished,
      'updated_ms', (extract(epoch from updated_at) * 1000)::bigint
    ) order by updated_at desc), '[]'::jsonb)
  from (select * from public.watch_history where user_id = auth.uid()
        order by updated_at desc limit 100) h
$$;

create or replace function public.delete_history_item(p_type text, p_id int, p_season int, p_episode int)
returns void language sql security definer set search_path = public as $$
  delete from public.watch_history
  where user_id = auth.uid() and media_type = p_type and tmdb_id = p_id
    and season = coalesce(p_season, 0) and episode = coalesce(p_episode, 0)
$$;

do $$
declare f text;
begin
  foreach f in array array[
    'ensure_profile(text)', 'claim_device(text)', 'heartbeat(text)', 'release_device(text)',
    'update_profile(text,int,text,boolean)',
    'save_progress(text,text,int,int,int,text,text,int,int)',
    'get_history()', 'delete_history_item(text,int,int,int)'
  ] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;
