Kujao Netflix

1. Ganti GITHUB_REPO di app/build.gradle.kts (contoh: "usernameku/kujao-netflix")
2. Buat keystore sekali saja:
   keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias kujao
3. Base64 keystore: base64 -w0 release.jks
4. GitHub repo, Settings, Secrets and variables, Actions, tambah:
   KEYSTORE_B64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
5. Rilis versi baru:
   git tag v1.0.1 && git push origin v1.0.1
   Actions otomatis build APK dan menaruhnya di GitHub Releases. App user dapat notif update.

Player: isi EMBED_TEMPLATE di app/build.gradle.kts, placeholder {type} dan {id}.
Jika berakhiran .m3u8 atau .mp4 dipakai ExoPlayer, selain itu dibuka lewat WebView.
Kosong berarti memutar trailer dari TMDB.
