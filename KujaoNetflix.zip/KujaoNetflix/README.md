# Kujao Netflix

## Build APK

The Android project uses Gradle 8.9, Java 17, Android Gradle Plugin 8.5.2, Kotlin 2.0.20, and Android SDK 34.

Build a debug APK locally from this directory:

```bash
gradle assembleDebug
```

The APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub release

The release workflow builds the project when a tag beginning with `v` is pushed.

For a signed release APK, create a keystore:

```bash
keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias kujao
```

Encode it as Base64 and add these repository Actions secrets:

- `KEYSTORE_B64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Without these secrets, the workflow still builds a release variant signed with the debug key. Do not distribute that build as a production release.

Create a release:

```bash
git tag v1.0.1
git push origin v1.0.1
```

## App configuration

The GitHub repository used by the in-app update checker is configured in `app/build.gradle.kts`.

The player template is configured through `EMBED_TEMPLATE`. It supports `{type}` and `{id}` placeholders. URLs ending in `.m3u8` or `.mp4` are played with Media3. Other non-empty URLs are opened in a WebView. When the template is empty, the app attempts to show a YouTube trailer.

## Backend akun (wajib untuk login, 1 akun 1 device, riwayat)

Akun, aturan 1 akun 1 device, ban, profil, dan riwayat tontonan disimpan di Supabase (gratis).

1. Buat project di supabase.com.
2. Authentication > Providers > Email: **matikan "Confirm email"**.
3. SQL Editor: jalankan seluruh isi `backend/supabase.sql` sekali.
4. Isi `supabaseUrl` dan `supabaseAnonKey` di `gradle.properties` (atau env `SUPABASE_URL`, `SUPABASE_ANON_KEY`). Pakai anon key, JANGAN service_role key.
5. Build ulang APK.

Aturan (ubah di `backend/supabase.sql`):

- Satu akun hanya boleh aktif di satu device. Device aktif mengirim heartbeat tiap 60 dtk; slot dianggap kosong setelah 3 menit tanpa kabar atau saat logout.
- Device lain yang login saat slot masih aktif = pelanggaran, device itu kena ban 1 jam (berdasarkan ANDROID_ID, bertahan walau clear data / install ulang).
- Ganti nama maksimal 1x per 24 jam (dicek di server). Foto profil dipilih dari galeri, dipotong 192px.
- Akun lama yang tersimpan lokal tidak ikut pindah; daftar ulang.

## Server video (otomatis)

Pengguna tidak memilih server. App mengurutkan server otomatis (FlaxMovies dulu), mengecek server teratas
lewat OkHttp, lalu pindah sendiri bila gagal dimuat / SSL error / HTTP 5xx / 404 / buffering macet 30 dtk /
error video. Server yang baru gagal ditunda 10 menit, server yang baru berhasil dinaikkan.

Tambah, hapus, atau ubah urutan server tanpa rilis APK baru lewat `servers.json` di root repo
(URL-nya `SERVERS_URL` di `app/build.gradle.kts`). Format: lihat `servers.json`
(`{tmdb} {imdb} {s} {e}` sebagai placeholder, wajib https).

## Riwayat & lanjut nonton

Posisi tonton (menit:detik) dibaca dari elemen `<video>` di dalam embed lewat script yang disuntik ke semua
frame (butuh Android System WebView 87+). Disimpan lokal tiap 10 dtk dan ke server tiap 30 dtk / saat keluar.
Judul yang belum selesai muncul di baris "Lanjutkan menonton", tombol di halaman detail, dan pop-up saat app dibuka.
