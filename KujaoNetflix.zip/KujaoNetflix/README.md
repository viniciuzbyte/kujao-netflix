# Kujao Netflix

## Build APK

The Android project uses Gradle 8.9, Java 17, Android Gradle Plugin 8.5.2, Kotlin 2.0.20, and Android SDK 34.

Build a debug APK locally from this directory:

```bash
gradle assembleDebug
```

The APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub release

The release workflow builds the project when a tag beginning with `v` is pushed.

For a signed release APK, create a keystore:

```bash
keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias kujao
```

Encode it as Base64 and add these repository Actions secrets:

- `KEYSTORE_B64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Without these secrets, the workflow still builds a release variant signed with the debug key. Do not distribute that build as a production release.

Create a release:

```bash
git tag v1.0.1
git push origin v1.0.1
```

## App configuration

The GitHub repository used by the in-app update checker is configured in `app/build.gradle.kts`.

The player template is configured through `EMBED_TEMPLATE`. It supports `{type}` and `{id}` placeholders. URLs ending in `.m3u8` or `.mp4` are played with Media3. Other non-empty URLs are opened in a WebView. When the template is empty, the app attempts to show a YouTube trailer.

## Account storage

Accounts are stored locally on the device. They are not synced to a server and will not be shared across devices.
